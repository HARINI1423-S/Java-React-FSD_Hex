package com.hex.CodingChallenge.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hex.CodingChallenge.Model.Customer;
import com.hex.CodingChallenge.Repository.CustomerProductRepository;
import com.hex.CodingChallenge.Repository.CustomerRepository;

@Service
public class CustomerProductService {
	
	private CustomerProductRepository customerProductRepository;
	private CustomerRepository customerRepository;
	



	public CustomerProductService(CustomerProductRepository customerProductRepository,
			CustomerRepository customerRepository) {
		super();
		this.customerProductRepository = customerProductRepository;
		this.customerRepository = customerRepository;
	}




	public List<Customer> get(String productTitle) {
		return customerRepository.getAllcustomers(productTitle);
	}

}
