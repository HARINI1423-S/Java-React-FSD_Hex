package com.hex.CodingChallenge.Enum;

public enum Speciality {

	PHYSICIAN,ORTHO,GYNAC
}
