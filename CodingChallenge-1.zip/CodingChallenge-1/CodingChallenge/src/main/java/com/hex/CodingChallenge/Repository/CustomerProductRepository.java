package com.hex.CodingChallenge.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hex.CodingChallenge.Model.Customer;

@Repository
public interface CustomerProductRepository extends JpaRepository<Customer, Integer>{


}
