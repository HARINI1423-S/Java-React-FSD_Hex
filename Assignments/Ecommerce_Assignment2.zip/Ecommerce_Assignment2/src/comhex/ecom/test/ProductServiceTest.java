package comhex.ecom.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.hex.ecom.Service.ProductService;
import com.hex.ecom.model.Product;



public class ProductServiceTest {
	 private ProductService productService;

	    @BeforeEach
	    public void setup() {
	        productService = new ProductService();
	    }

	    @Test
	    public void testAddProduct_StockAvailable_SetStatusAvailable() {
	        Product product = new Product();
	        product.setName("Keyboard");
	        product.setCount(5);
	        product.setPrice(999.0);
	        product.setCategory_id(1);

	        productService.addProduct(product);

	        assertEquals("Available", product.getStatus());
	        assertTrue(product.getId() >= 20250000); // since ID is generated randomly above 20250000
	    }

	    @Test
	    public void testAddProduct_NoStock_SetStatusOutOfStock() {
	        Product product = new Product();
	        product.setName("Mouse");
	        product.setCount(0);
	        product.setPrice(599.0);
	        product.setCategory_id(2);

	        productService.addProduct(product);
	        assertEquals("Out of Stock", product.getStatus());
	    }

	    @Test
	    public void testViewByCategory_shouldNotThrowException() {
	        assertDoesNotThrow(() -> productService.viewByCategory(1));
	    }
	}


