package comhex.ecom.test;
import com.hex.ecom.Service.PurchaseService;
import com.hex.ecom.enums.Coupon;
import com.hex.ecom.model.Purchase;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class PurchaseServiceTest {
	private PurchaseService purchaseService;
	
	@BeforeEach
    public void setup() {
        purchaseService = new PurchaseService();
    }

    @Test
    public void testInsertPurchase_shouldSetDateAndId() {
        Purchase purchase = new Purchase();
        purchase.setCustomer_id(101);
        purchase.setProduct_id(202);
        purchase.setCoupon_code(Coupon.DIWALI_05); 

        purchaseService.insert(purchase);

        assertNotNull(purchase.getDate());
        assertTrue(purchase.getId() >= 0); 
        assertEquals(LocalDate.now(), purchase.getDate());
    }

}
