package com.hex.ecom.Utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtility {
    private static DBUtility instance;
    private Connection connection;
    private static final String URL = "jdbc:mysql://localhost:3306/ecommerce_db?useSSL=false";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Harini@1423";

    private DBUtility() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (Exception e) {
            System.out.println("Error initializing DB: " + e.getMessage());
        }
    }

    public static DBUtility getInstance() {
        if (instance == null) {
            instance = new DBUtility();
        }
        return instance;
    }

    public Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            }
        } catch (SQLException e) {
            System.out.println("Connection error: " + e.getMessage());
        }
        return connection;
    }

    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.out.println("Error closing connection: " + e.getMessage());
        }
    }
}
