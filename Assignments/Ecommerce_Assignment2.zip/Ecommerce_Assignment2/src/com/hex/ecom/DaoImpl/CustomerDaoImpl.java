package com.hex.ecom.DaoImpl;

import com.hex.ecom.Dao.CustomerDao;

public class CustomerDaoImpl implements CustomerDao{

}
