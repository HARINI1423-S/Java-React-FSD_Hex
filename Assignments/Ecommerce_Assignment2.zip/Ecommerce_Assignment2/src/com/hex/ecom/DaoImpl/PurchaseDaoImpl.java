package com.hex.ecom.DaoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.hex.ecom.Dao.PurchaseDao;
import com.hex.ecom.exceptions.InvalidInputException;
import com.hex.ecom.model.Purchase;
import com.hex.ecom.Utility.DBUtility;

public class PurchaseDaoImpl implements PurchaseDao {

    DBUtility db = DBUtility.getInstance(); 

    @Override
    public void AddPurchase(Purchase purchase) throws InvalidInputException {
        String query = "INSERT INTO purchase (id, customer_id, product_id, purchase_date, coupon_code) VALUES (?, ?, ?, ?, ?)";
        Connection conn = db.getConnection();

        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, purchase.getId());
            ps.setInt(2, purchase.getCustomer_id());
            ps.setInt(3, purchase.getProduct_id());
            ps.setString(4, purchase.getDate().toString());
            ps.setString(5, purchase.getCoupon_code().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error inserting data: " + e.getMessage());
        }
    }
}
