package com.hex.ecom.DaoImpl;

import com.hex.ecom.Dao.CategoryDao;

public class CategoryDaoImpl implements CategoryDao {

}
