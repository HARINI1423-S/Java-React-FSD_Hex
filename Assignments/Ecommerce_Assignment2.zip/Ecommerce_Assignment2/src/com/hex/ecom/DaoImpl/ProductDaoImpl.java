package com.hex.ecom.DaoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hex.ecom.Dao.ProductDao;
import com.hex.ecom.exceptions.InvalidIdException;
import com.hex.ecom.exceptions.InvalidInputException;
import com.hex.ecom.model.Product;
import com.hex.ecom.Utility.DBUtility;

public class ProductDaoImpl implements ProductDao {
	
	DBUtility db=DBUtility.getInstance();
	@Override
	public void AddProduct(Product product) throws InvalidInputException {
		// TODO Auto-generated method stub
		Connection conn=db.getConnection();
		String query="insert into product (id,name,count,status,category_id,price) "
				+ "values(?,?,?,?,?,?)";
		
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, product.getId());
			ps.setString(2, product.getName());
			ps.setInt(3, product.getCount());
			ps.setString(4, product.getStatus());
			ps.setInt(5, product.getCategory_id());
			ps.setDouble(6, product.getPrice());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("DB Error: " +e.getMessage());
		}finally {
			db.closeConnection();
		}
		
	}

	@Override
	public List<Product> GetProductByCategory(int id) throws InvalidIdException{
		String query="Select * from product where category_id=?";
		List<Product> list=new ArrayList<Product>();
		Connection conn=db.getConnection();
		
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Product product=new Product();
				product.setId(rs.getInt("id"));
				product.setStatus(rs.getString("status"));
				product.setCategory_id(rs.getInt("category_id"));
				product.setName(rs.getString("name"));
				list.add(product);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error retreving data: "+e.getMessage());
		}
		
		
		return null;
		// TODO Auto-generated method stub
		
		
	}

}
