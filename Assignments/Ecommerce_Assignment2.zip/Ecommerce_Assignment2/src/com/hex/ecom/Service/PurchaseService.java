package com.hex.ecom.Service;

import java.time.LocalDate;

import com.hex.ecom.DaoImpl.PurchaseDaoImpl;
import com.hex.ecom.enums.Coupon;
import com.hex.ecom.exceptions.InvalidInputException;
import com.hex.ecom.model.Purchase;
public class PurchaseService {

	PurchaseDaoImpl dao=new PurchaseDaoImpl();
	public void insert(Purchase purchase) {
		// TODO Auto-generated method stub
		int id=(int)(Math.random()*1000);
		purchase.setId(id);
		purchase.setDate(LocalDate.now());
		try {
			dao.AddPurchase(purchase);
		} catch (InvalidInputException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
	}

}