package com.hex.ecom.enums;

public enum Coupon {
	 
	NEW_USER_10(10),
	ACT_20(20),
	DIWALI_05(5),
	FREE_10(10);
	
	private int value;
	
	Coupon(int val){
		this.value=val;
	}

	public int getValue() {
		return value;
	}
	
	
}
