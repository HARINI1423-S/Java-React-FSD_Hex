package com.hex.ecom.enums;

public enum Status {
	IN_STOCK,OUT_OF_STOCK;
}
