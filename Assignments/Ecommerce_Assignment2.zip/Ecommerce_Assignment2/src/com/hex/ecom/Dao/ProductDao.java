package com.hex.ecom.Dao;

import java.util.List;

import com.hex.ecom.exceptions.InvalidIdException;
import com.hex.ecom.exceptions.InvalidInputException;
import com.hex.ecom.model.Product;

public interface ProductDao {
	
	public void AddProduct(Product product) throws InvalidInputException;
	public List<Product> GetProductByCategory(int id) throws InvalidIdException;

}
