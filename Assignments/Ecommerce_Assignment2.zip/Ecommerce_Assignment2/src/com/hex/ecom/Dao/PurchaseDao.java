package com.hex.ecom.Dao;

import com.hex.ecom.model.Purchase;
import com.hex.ecom.exceptions.InvalidInputException;

public interface PurchaseDao {
    void AddPurchase(Purchase purchase) throws InvalidInputException;
}
