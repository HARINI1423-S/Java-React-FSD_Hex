package com.hex.ecom.Dao;

public interface CategoryDao {
  /* Data manually added in DB,
   * So No declaration and no implementation */
}
