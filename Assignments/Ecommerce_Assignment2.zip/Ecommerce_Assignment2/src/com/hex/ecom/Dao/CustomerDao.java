package com.hex.ecom.Dao;

public interface CustomerDao {

	 /* Data manually added in DB,
	   * So No declaration and no implementation */
}
