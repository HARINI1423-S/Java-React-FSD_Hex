package com.hex.mockSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockApplicationTests {

	@Test
	void contextLoads() {
	}

}
