package com.hex.mockSpring;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.hex.hms.Exception.ResourceNotFoundException;
import com.hex.hms.enums.Speciality;
import com.hex.hms.model.Doctor;
import com.hex.hms.model.Patient;
import com.hex.hms.model.User;
import com.hex.hms.repository.DoctorRepository;
import com.hex.hms.repository.PatientRepository;
import com.hex.hms.service.PatientService;

@SpringBootTest
public class GetAllPatientsByDoctorIdTestMock {

    @InjectMocks
    private PatientService patientService;

    @Mock
    private PatientRepository patientRepository;

    @Mock
    private DoctorRepository doctorRepository;

    private User doctorUser;
    private User patientUser;
    private Doctor doctor;
    private Patient patient;

    @BeforeEach
    public void setup() {
        // Setup patient user
        patientUser = new User();
        patientUser.setId(4);
        patientUser.setUsername("kiwi.patient@Hms.com");
        patientUser.setPassword("$2a$10$pD5QlALnCV.5w1beeAd3fe0dgMTOfIqjvVq7zTOSI3gsb29pjFVfC");
        patientUser.setRole("PATIENT");

        // Setup patient
        patient = new Patient();
        patient.setId(1);
        patient.setName("kiwi");
        patient.setAge(34);
        patient.setUser(patientUser);

        // Setup doctor user
        doctorUser = new User();
        doctorUser.setId(1);
        doctorUser.setUsername("Harini.doctor@Hms.com");
        doctorUser.setPassword("Harini@123");
        doctorUser.setRole("DOCTOR");

        // Setup doctor
        doctor = new Doctor();
        doctor.setId(1);
        doctor.setName("Harini");
        doctor.setSpeciality(Speciality.ORTHO);
        doctor.setUser(doctorUser);

        // IMPORTANT: Set patients list in doctor, as service calls doctor.getPatients()
        doctor.setPatients(List.of(patient));
    }

    @Test
    public void getPatientsByDoctorId_Success() {
        // Mock doctorRepository.findById to return doctor with patients list
        when(doctorRepository.findById(doctor.getId())).thenReturn(Optional.of(doctor));

        // Call service method
        List<Patient> result = patientService.getPatientsByDoctorId(doctor.getId());

        // Assert returned patients match expected list
        assertEquals(1, result.size());
        assertEquals(patient, result.get(0));
    }

    @Test
    public void getPatientsByDoctorId_DoctorNotFound() {
        // Mock doctorRepository.findById to return empty for invalid id
        when(doctorRepository.findById(999)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            patientService.getPatientsByDoctorId(999);
        });

        assertTrue(exception.getMessage().contains("Doctor not found"));
    }
}
