package com.hex.hms.DTO;

public class AppointmentRequestDTO {
	
	private int doctorId;
	
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	
	

}
