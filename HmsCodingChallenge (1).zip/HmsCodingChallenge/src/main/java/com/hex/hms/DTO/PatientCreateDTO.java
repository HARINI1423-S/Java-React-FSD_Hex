package com.hex.hms.DTO;

import java.util.List;

public class PatientCreateDTO {
	
	  private String username;
	    private String password;
	    private String name;
	    private int age;
	    private String role = "PATIENT";
	    private List<MedicalHistoryDTO> medicalHistory;
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		public List<MedicalHistoryDTO> getMedicalHistory() {
			return medicalHistory;
		}
		public void setMedicalHistory(List<MedicalHistoryDTO> medicalHistory) {
			this.medicalHistory = medicalHistory;
		}

	    
}
