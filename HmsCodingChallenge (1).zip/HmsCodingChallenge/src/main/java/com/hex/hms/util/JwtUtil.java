package com.hex.hms.util;

import java.security.Key;
import java.util.Date;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {

	private static final String secretKey = "LMS_HEX_MAY_7867486754876768463_2024"; 
	private static final long expirationTimeInMills = 43200000; 
	private final Key key = Keys.hmacShaKeyFor(secretKey.getBytes());

	public String createToken(String email) {
		return Jwts.builder().setSubject(email).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + expirationTimeInMills))
				.signWith(key, SignatureAlgorithm.HS256).compact(); // generate the actual JWT string
	}

	public boolean verifyToken(String token, String email) {
		String extractedEmail = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody()
				.getSubject();

		Date expirationDate = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody()
				.getExpiration();

		return extractedEmail.equals(email) && new Date().before(expirationDate);
	}

	public String extractUsername(String token) {
		return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token).getBody().getSubject();
	}

}
