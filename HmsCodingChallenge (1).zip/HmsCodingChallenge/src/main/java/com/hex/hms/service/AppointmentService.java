package com.hex.hms.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.hex.hms.DTO.AppointmentRequestDTO;
import com.hex.hms.model.Doctor;
import com.hex.hms.model.Patient;
import com.hex.hms.model.User;
import com.hex.hms.repository.DoctorRepository;
import com.hex.hms.repository.PatientRepository;
import com.hex.hms.repository.UserRepository;
@Service
public class AppointmentService {
	
    private PatientRepository patientRepository;

    private DoctorRepository doctorRepository;

    private UserRepository userRepository;
	
    

	public AppointmentService(PatientRepository patientRepository, DoctorRepository doctorRepository,
			UserRepository userRepository) {
		super();
		this.patientRepository = patientRepository;
		this.doctorRepository = doctorRepository;
		this.userRepository = userRepository;
	}



	public Object bookAppointment(AppointmentRequestDTO dto, String username) {
        Optional<User> optionalUser = userRepository.findByUsername(username);
        if (optionalUser.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("User not found");
        }
        User user = optionalUser.get();
        
        // Find Patient by User
        Optional<Patient> optionalPatient = patientRepository.findByUser(user);
        if (optionalPatient.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Patient profile not found");
        }
        Patient patient = optionalPatient.get();

        // Find Doctor by id from DTO
        Optional<Doctor> optionalDoctor = doctorRepository.findById(dto.getDoctorId());
        if (optionalDoctor.isEmpty()) {
            return ResponseEntity.badRequest().body("Invalid doctor ID");
        }
        Doctor doctor = optionalDoctor.get();

        // Add doctor to patient's doctor list if not already added
        if (!patient.getDoctors().contains(doctor)) {
            patient.getDoctors().add(doctor);
        }

        // Add patient to doctor's patient list if not already added
        if (!doctor.getPatients().contains(patient)) {
            doctor.getPatients().add(patient);
        }

        patientRepository.save(patient);
        doctorRepository.save(doctor);

        return ResponseEntity.ok("Appointment booked successfully");
    }
	
}
