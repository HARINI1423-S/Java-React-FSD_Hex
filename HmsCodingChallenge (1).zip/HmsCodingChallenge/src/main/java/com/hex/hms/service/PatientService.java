package com.hex.hms.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.hex.hms.DTO.MedicalHistoryDTO;
import com.hex.hms.DTO.PatientCreateDTO;
import com.hex.hms.model.Doctor;
import com.hex.hms.model.MedicalHistory;
import com.hex.hms.model.Patient;
import com.hex.hms.model.User;
import com.hex.hms.repository.DoctorRepository;
import com.hex.hms.repository.MedicalHistoryRepository;
import com.hex.hms.repository.PatientRepository;
import com.hex.hms.repository.UserRepository;

@Service
public class PatientService {


	private UserRepository userRepository;
	private PatientRepository patientRepository;
	private MedicalHistoryRepository medicalHistoryRepository;
	private DoctorRepository doctorRepository;
	
	



	public PatientService(UserRepository userRepository, PatientRepository patientRepository,
			MedicalHistoryRepository medicalHistoryRepository, DoctorRepository doctorRepository) {
		super();
		this.userRepository = userRepository;
		this.patientRepository = patientRepository;
		this.medicalHistoryRepository = medicalHistoryRepository;
		this.doctorRepository = doctorRepository;
	}



	public Object createPatient(PatientCreateDTO dto, String username) {
	        Optional<User> optionalUser = userRepository.findByUsername(username);

	        if (optionalUser.isEmpty()) {
	            return ResponseEntity.badRequest().body("User not found!Please sign up first");
	        }

	        User user = optionalUser.get();
	        if (!user.getRole().equalsIgnoreCase("PATIENT")) {
	            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Only patients can create patient profile");
	        }

	        Patient patient = new Patient();
	        patient.setName(dto.getName());
	        patient.setAge(dto.getAge());
	        patient.setUser(user);

	        List<MedicalHistory> histories = new ArrayList<>();
	        for (MedicalHistoryDTO h : dto.getMedicalHistory()) {
	            MedicalHistory mh = new MedicalHistory();
	            mh.setIllness(h.getIllness());
	            mh.setNumOfYears(h.getNumOfYears());
	            mh.setCurrentMedication(h.getCurrentMedication());
	            mh.setPatient(patient);
	            histories.add(mh);
	        }

	        patient.setMedicalHistories(histories);
	        patientRepository.save(patient);

	        return ResponseEntity.ok("Patient registered successfully.");
	    }



	public List<Patient> getPatientsByDoctorId(int doctorId) {
	    Doctor doctor = doctorRepository.findById(doctorId)
	        .orElseThrow(() -> new RuntimeException("Doctor not found"));

	    return doctor.getPatients();
	}

	public MedicalHistoryDTO getMedicalHistoryByPatientId(int patientId) {
	    MedicalHistory history = medicalHistoryRepository.findByPatientId(patientId)
	        .orElseThrow(() -> new RuntimeException("Medical history not found"));

	    return new MedicalHistoryDTO(
	        history.getIllness(),
	        history.getNumOfYears(),
	        history.getCurrentMedication()
	    );
	}



	


}
	
	