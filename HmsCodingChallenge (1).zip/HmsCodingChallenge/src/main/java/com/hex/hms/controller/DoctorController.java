package com.hex.hms.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hex.hms.model.Doctor;
import com.hex.hms.service.DoctorService;
import com.hex.hms.service.PatientService;

@RestController
@RequestMapping("/api/doctor")
public class DoctorController {
	
    @Autowired
    private DoctorService doctorService;
    
    @Autowired
    private PatientService patientService;

    
    // create doctor
    @PostMapping("/create")
    public ResponseEntity<?> createDoctor(@RequestBody Doctor doctor, Principal principal) {
    	String username=principal.getName();
    	return ResponseEntity.status(HttpStatus.OK).body(doctorService.createDoctor(doctor,username));
       
    }
    
    
    //get all patient based on doctor ID
    @GetMapping("/byDoctor/{doctorId}")
    public ResponseEntity<?> getPatientsByDoctor(@PathVariable int doctorId) {
        return ResponseEntity.ok(patientService.getPatientsByDoctorId(doctorId));
    }
    
    //Get patients medical history by patient ID
    @GetMapping("/medicalHistory/{Id}")
    public ResponseEntity<?> getMedicalHistory(@PathVariable int id) {
        return ResponseEntity.ok(patientService.getMedicalHistoryByPatientId(id));
    }


  
}

	
	

