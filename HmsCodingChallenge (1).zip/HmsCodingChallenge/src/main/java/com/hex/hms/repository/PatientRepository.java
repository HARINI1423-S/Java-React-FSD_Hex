package com.hex.hms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hex.hms.model.Patient;
import com.hex.hms.model.User;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Integer>{

	  @Query("SELECT p FROM Patient p WHERE p.user = :user")
	Optional<Patient> findByUser(User user);

}
