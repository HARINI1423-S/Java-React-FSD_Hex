package com.hex.hms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hex.hms.model.User;
import com.hex.hms.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;
	

	public UserService(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}


	public ResponseEntity<?> signup(User user) {
		 if (userRepository.findByUsername(user.getUsername()).isPresent()) {
	            return ResponseEntity.badRequest().body("Username already taken.");
	        }
		 String encryptedPassword = passwordEncoder.encode(user.getPassword());
		    user.setPassword(encryptedPassword);

	        userRepository.save(user);
	        return ResponseEntity.ok("User registered successfully.");
	    }
	}
	

