package com.hex.hms.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hex.hms.DTO.MedicalHistoryDTO;
import com.hex.hms.DTO.PatientCreateDTO;
import com.hex.hms.model.MedicalHistory;
import com.hex.hms.model.Patient;
import com.hex.hms.model.User;
import com.hex.hms.repository.MedicalHistoryRepository;
import com.hex.hms.repository.PatientRepository;
import com.hex.hms.repository.UserRepository;
import com.hex.hms.service.PatientService;

@RestController
@RequestMapping("/api/patient")
public class PatientController {

	@Autowired
	private PatientService patientService;
	
	
	@PostMapping("/register")
    public ResponseEntity<?> createPatient(@RequestBody PatientCreateDTO dto, Principal principal) {
			String username=principal.getName();
		return ResponseEntity.status(HttpStatus.OK).body(patientService.createPatient(dto,username));
	}
	
}
