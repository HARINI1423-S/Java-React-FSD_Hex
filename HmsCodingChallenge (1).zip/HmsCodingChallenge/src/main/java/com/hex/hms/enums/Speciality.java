package com.hex.hms.enums;

public enum Speciality {
	PHYSICIAN,
    ORTHO,
    GYNAC
}
