package com.hex.hms.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hex.hms.model.User;
import com.hex.hms.service.UserService;
import com.hex.hms.util.JwtUtil;

@RestController
@RequestMapping("/api/user")
public class UserController {
	
	 	@Autowired
	    private UserService userService;
	 	@Autowired
	 	private JwtUtil jwtUtil;

	    @PostMapping("/signup")
	    public ResponseEntity<?> signup(@RequestBody User user) {
	       return userService.signup(user);
	}
	    
	    @GetMapping("/token")
		public String getToken(Principal principal) {
			String token =jwtUtil.createToken(principal.getName());
			return token;
			
		}
}