package com.hex.hms.service;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.hex.hms.model.Doctor;
import com.hex.hms.model.User;
import com.hex.hms.repository.DoctorRepository;
import com.hex.hms.repository.UserRepository;

@Service
public class DoctorService {
	
	private DoctorRepository doctorRepository;
	private UserRepository userRepository;
	

	public DoctorService(DoctorRepository doctorRepository, UserRepository userRepository) {
		super();
		this.doctorRepository = doctorRepository;
		this.userRepository = userRepository;
	}


	public Object createDoctor(Doctor doctor, String username) {
	        User user = userRepository.findByUsername(username)
	            .orElseThrow(() -> new UsernameNotFoundException("User not found"));

	        if (!user.getRole().equalsIgnoreCase("DOCTOR")) {
	            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Only users with role DOCTOR can create doctor profile");
	        }

	        doctor.setUser(user);
	        doctorRepository.save(doctor);
	        return ResponseEntity.ok("Doctor profile created");
	}
	
	
	

}
