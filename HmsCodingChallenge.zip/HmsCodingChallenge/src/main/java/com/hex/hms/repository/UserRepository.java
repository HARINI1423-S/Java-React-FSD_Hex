package com.hex.hms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hex.hms.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
	 @Query("SELECT u FROM User u WHERE u.username = :username")
	User getByUsername(String username);

	 @Query("SELECT u FROM User u WHERE u.username = :username")
	Optional<User> findByUsername(String username);


}
