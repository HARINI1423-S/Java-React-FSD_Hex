package com.hex.hms.model;

import java.util.List;

import com.hex.hms.enums.Speciality;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="doctor")
public class Doctor {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int id;

	    private String name;

	    @Enumerated(EnumType.STRING)
	    private Speciality speciality;

	    @OneToOne
	    @JoinColumn(name="user_id",unique = true)
	    private User user;

	    @ManyToMany
	    private List<Patient> patients;

		public Doctor() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Doctor(int id, String name, Speciality speciality, User user, List<Patient> patients) {
			super();
			this.id = id;
			this.name = name;
			this.speciality = speciality;
			this.user = user;
			this.patients = patients;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Speciality getSpeciality() {
			return speciality;
		}

		public void setSpeciality(Speciality speciality) {
			this.speciality = speciality;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

		public List<Patient> getPatients() {
			return patients;
		}

		public void setPatients(List<Patient> patients) {
			this.patients = patients;
		}
	
	

}
