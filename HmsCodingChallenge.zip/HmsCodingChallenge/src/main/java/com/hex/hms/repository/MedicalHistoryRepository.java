package com.hex.hms.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hex.hms.model.MedicalHistory;
import com.hex.hms.model.User;

@Repository
public interface MedicalHistoryRepository extends JpaRepository<MedicalHistory, Integer>{

	@Query("SELECT m FROM MedicalHistory m WHERE m.patient.id = :patientId")
	Optional<MedicalHistory> findByPatientId(int patientId);

}
