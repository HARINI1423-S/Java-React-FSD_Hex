package com.hex.hms.controller;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hex.hms.DTO.AppointmentRequestDTO;
import com.hex.hms.model.Doctor;
import com.hex.hms.model.Patient;
import com.hex.hms.model.User;
import com.hex.hms.repository.DoctorRepository;
import com.hex.hms.repository.PatientRepository;
import com.hex.hms.repository.UserRepository;
import com.hex.hms.service.AppointmentService;

@RestController
@RequestMapping("/api/appointment")
public class AppointmentController {
	
	    
	    @Autowired
	    private AppointmentService appointmentService;
	    
	    @PostMapping("/book")
	    public ResponseEntity<?> bookAppointment(@RequestBody AppointmentRequestDTO dto, Principal principal) {
	    	String username=principal.getName();
	    
	       return ResponseEntity.status(HttpStatus.OK).body(appointmentService.bookAppointment(dto,username));

	}
}