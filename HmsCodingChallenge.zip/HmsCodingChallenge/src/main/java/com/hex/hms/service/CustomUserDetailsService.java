
package com.hex.hms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.hex.hms.repository.UserRepository;
@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		com.hex.hms.model.User user=userRepository.getByUsername(username);
		
		 if(user == null)
			throw new UsernameNotFoundException("Invalid Credentials");
		 SimpleGrantedAuthority sga=new SimpleGrantedAuthority(user.getRole());
		 
		 List<GrantedAuthority> list=List.of(sga);
		User springUser=new User(user.getUsername(),
								user.getPassword(),
								list);
		return springUser;
	}
}
