package com.Hex.MaverickBank.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.dto.TransactionResponseDTO;
import com.Hex.MaverickBank.enums.TxnType;
import com.Hex.MaverickBank.exception.IdNotFoundException;
import com.Hex.MaverickBank.exception.InSufficientBalanceException;
import com.Hex.MaverickBank.model.Account;
import com.Hex.MaverickBank.model.Transaction;
import com.Hex.MaverickBank.model.User;
import com.Hex.MaverickBank.repository.AccountRepository;
import com.Hex.MaverickBank.repository.TransactionRepository;
import com.Hex.MaverickBank.repository.UserRepository;

@Service
public class TransactionService {
	
	private TransactionRepository transactionRepository;
	private AccountRepository accountRepository;
	private UserRepository userRepository;
	
	public TransactionService(TransactionRepository transactionRepository, AccountRepository accountRepository,
			UserRepository userRepository) {
		super();
		this.transactionRepository = transactionRepository;
		this.accountRepository = accountRepository;
		this.userRepository = userRepository;
	}


	public Transaction deposit(String username, BigDecimal amount) throws IdNotFoundException {
		User user=userRepository.findByUsername(username)
				.orElseThrow(()->new IdNotFoundException("Account not found"));
		
		Account account = accountRepository.findByAccountHolderUserUsername(username)
	            .orElseThrow(() -> new IdNotFoundException("Account not found for user:" + username));

		account.setBalance(account.getBalance().add(amount));
		accountRepository.save(account);
		
		Transaction transaction=new Transaction();
		transaction.setAccount(account);
		transaction.setType(TxnType.DEPOSIT);
		transaction.setAmount(amount);
		transaction.setDescription("Deposit to account");
		
		return transactionRepository.save(transaction);
		
	}


	public Transaction withdraw(String username, BigDecimal amount) throws IdNotFoundException, InSufficientBalanceException {
		
		User user=userRepository.findByUsername(username)
				.orElseThrow(()->new IdNotFoundException("Account not found"));
		
		Account account = accountRepository.findByAccountHolderUserUsername(username)
	            .orElseThrow(() -> new IdNotFoundException("Account not found for user: " + username));
		
		if(account.getBalance().compareTo(amount)<0) {
			throw new InSufficientBalanceException("Insufficient balance");
		}
		
		account.setBalance(account.getBalance().subtract(amount));
		accountRepository.save(account);
		
		Transaction transaction=new Transaction();
		transaction.setAccount(account);
		transaction.setType(TxnType.WITHDRAW);
		transaction.setAmount(amount);
		transaction.setDescription("Withdrawal from account");
		
		return transactionRepository.save(transaction);
	}


	public Transaction transfer(String username, Long toAccountId, BigDecimal amount)
	        throws IdNotFoundException, InSufficientBalanceException {

		Account fromAccount = accountRepository.findByAccountHolderUserUsername(username)
	            .orElseThrow(() -> new IdNotFoundException("Sender account not found"));

	    Account toAccount = accountRepository.findById(Math.toIntExact(toAccountId))
	            .orElseThrow(() -> new IdNotFoundException("Receiver account not found"));
	
	    if (fromAccount.getBalance().compareTo(amount) < 0) {
	        throw new InSufficientBalanceException("Insufficient balance for transaction");
	    }

	   
	    fromAccount.setBalance(fromAccount.getBalance().subtract(amount));
	    toAccount.setBalance(toAccount.getBalance().add(amount));
	    accountRepository.save(fromAccount);
	    accountRepository.save(toAccount);

	    
	    Transaction transaction = new Transaction();
	    transaction.setAccount(fromAccount);
	    transaction.setType(TxnType.TRANSFER);
	    transaction.setAmount(amount);
	    transaction.setReferenceAccount(toAccount.getAccountHolder().getFullName());
	    transaction.setDescription("Transferred to " + toAccount.getAccountHolder().getFullName());

	    return transactionRepository.save(transaction);
	}


	public List<TransactionResponseDTO> getLast10Transactions(Long accountId) {
		PageRequest limit=PageRequest.of(0, 10);
		List<Transaction> transactions = transactionRepository.getLast10Transactions(accountId, limit);

	    return transactions.stream().map(t -> {
	        TransactionResponseDTO dto = new TransactionResponseDTO();
	        dto.setTransactionId(t.getId());
	        dto.setType(t.getType().toString());
	        dto.setAmount(t.getAmount());
	        dto.setTimestamp(t.getTimestamp());
	        dto.setDescription(t.getDescription());
	        dto.setReferenceAccount(t.getReferenceAccount());
	        dto.setAccountId(t.getAccount().getId());
	        dto.setAccountType(t.getAccount().getAccountType().toString());
	        dto.setAvailableBalance(t.getAccount().getBalance());
	        return dto;
	    }).collect(Collectors.toList());
	}


	public List<TransactionResponseDTO> getTransactionsBetweenDates(Long accountId, LocalDateTime from, LocalDateTime to) {
		List<Transaction> transactions= transactionRepository.getTransactionBetweenDates(accountId,from,to);
		return transactions.stream().map(t -> {
	        TransactionResponseDTO dto = new TransactionResponseDTO();
	        dto.setTransactionId(t.getId());
	        dto.setType(t.getType().toString());
	        dto.setAmount(t.getAmount());
	        dto.setTimestamp(t.getTimestamp());
	        dto.setDescription(t.getDescription());
	        dto.setReferenceAccount(t.getReferenceAccount());
	        dto.setAccountId(t.getAccount().getId());
	        dto.setAccountType(t.getAccount().getAccountType().toString());
	        dto.setAvailableBalance(t.getAccount().getBalance());
	        return dto;
	    }).collect(Collectors.toList());
	}
	
	
	
	
	

}
