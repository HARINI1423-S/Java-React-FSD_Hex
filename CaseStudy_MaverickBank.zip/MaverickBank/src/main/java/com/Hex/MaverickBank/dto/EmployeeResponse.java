package com.Hex.MaverickBank.dto;

public class EmployeeResponse {

}
