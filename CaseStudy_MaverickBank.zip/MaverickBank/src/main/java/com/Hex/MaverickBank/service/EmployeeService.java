package com.Hex.MaverickBank.service;

import java.math.BigDecimal;
import java.nio.file.AccessDeniedException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.dto.ReportDTO;
import com.Hex.MaverickBank.enums.Designation;
import com.Hex.MaverickBank.enums.LoanStatus;
import com.Hex.MaverickBank.enums.ReportType;
import com.Hex.MaverickBank.enums.RequestStatus;
import com.Hex.MaverickBank.enums.TxnType;
import com.Hex.MaverickBank.model.Account;
import com.Hex.MaverickBank.model.AccountClosureRequest;
import com.Hex.MaverickBank.model.AccountCreateRequest;
import com.Hex.MaverickBank.model.Employee;
import com.Hex.MaverickBank.model.Loan;
import com.Hex.MaverickBank.model.Report;
import com.Hex.MaverickBank.model.Transaction;
import com.Hex.MaverickBank.repository.AccountClosureRequestRepository;
import com.Hex.MaverickBank.repository.AccountCreateRequestRepository;
import com.Hex.MaverickBank.repository.AccountRepository;
import com.Hex.MaverickBank.repository.EmployeeRepository;
import com.Hex.MaverickBank.repository.LoanRepository;
import com.Hex.MaverickBank.repository.ReportRepository;
import com.Hex.MaverickBank.repository.TransactionRepository;

@Service
public class EmployeeService {


	AccountCreateRequestRepository accountCreateRequestRepository;
	AccountRepository accountRepository;
	AccountClosureRequestRepository ClosureRequestRepository;
	TransactionRepository transactionRepository;
	LoanRepository loanRepository;
	ReportRepository reportRepository;
	EmployeeRepository employeeRepository;
	
	
	public EmployeeService(AccountCreateRequestRepository accountCreateRequestRepository,
			AccountRepository accountRepository, AccountClosureRequestRepository closureRequestRepository,
			TransactionRepository transactionRepository, LoanRepository loanRepository,
			ReportRepository reportRepository, EmployeeRepository employeeRepository) {
		super();
		this.accountCreateRequestRepository = accountCreateRequestRepository;
		this.accountRepository = accountRepository;
		ClosureRequestRepository = closureRequestRepository;
		this.transactionRepository = transactionRepository;
		this.loanRepository = loanRepository;
		this.reportRepository = reportRepository;
		this.employeeRepository = employeeRepository;
	}

	public String approveAccount(Long id,String empname) throws AccessDeniedException {
		
		Employee emp = employeeRepository.findByUsername(empname)
		            .orElseThrow(() -> new RuntimeException("Employee not found"));
	       
	        if (emp.getDesignation() != Designation.EXECUTIVE && emp.getDesignation() != Designation.MANAGER) {
	            throw new AccessDeniedException("Access denied for designation: " + emp.getDesignation());
	        }
		
		AccountCreateRequest request=accountCreateRequestRepository.findById(id)
				.orElseThrow(()->new RuntimeException("Account Create Request not found for the account"));
		if (request.getStatus() != RequestStatus.PENDING) {
	        throw new RuntimeException("Request already processed");
	    }
		
	    Account account = new Account();
	    account.setAccountHolder(request.getAccountHolder());
	    account.setAccountType(request.getAccountType());
	    account.setBranch(request.getBranch());
	    account.setIfscCode(request.getIfscCode());
	    account.setActive(true);
	    accountRepository.save(account);

	    request.setStatus(RequestStatus.APPROVED);
	    request.setApprovedBy(emp.getName());
	    request.setApprovedDate(LocalDate.now());
	    accountCreateRequestRepository.save(request);

	    return "Account approved Successfully";
	
	}

	public String rejectAccount(int requestId, String empname) throws AccessDeniedException {
		 Employee emp = employeeRepository.findByUsername(empname)
	                .orElseThrow(() -> new RuntimeException("Employee not found"));

	        if (emp.getDesignation() != Designation.MANAGER) {
	            throw new AccessDeniedException("Only Manager can reject account closures");
	        }
		AccountClosureRequest request = ClosureRequestRepository.findById(requestId)
                .orElseThrow(() -> new RuntimeException("Account Closure Request not found"));

        request.setStatus(RequestStatus.REJECTED);
        request.setApprovedBy(emp.getName());
        ClosureRequestRepository.save(request);        
        return "Account creation request rejected by "+ emp.getName() ;
	}



	public List<Account> getAllAccounts(String empname) throws AccessDeniedException {
		Employee emp = employeeRepository.findByUsername(empname)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        if (emp.getDesignation() != Designation.EXECUTIVE && emp.getDesignation() != Designation.MANAGER) {
            throw new AccessDeniedException("Access denied for designation: " + emp.getDesignation());
        }

        return accountRepository.findByAssignedEmployee(emp.getName());
    }


	

	public List<Transaction> getTransactionsByAccountId(int accountId, String empname) throws AccessDeniedException {
		 Employee emp = employeeRepository.findByUsername(empname)
	                .orElseThrow(() -> new RuntimeException("Employee not found"));

	        if (emp.getDesignation() != Designation.EXECUTIVE && emp.getDesignation() != Designation.MANAGER) {
	            throw new AccessDeniedException("Access denied for designation: " + emp.getDesignation());
	        }

	        Account account = accountRepository.findById(accountId)
	                .orElseThrow(() -> new RuntimeException("Account not found"));

	        if (emp.getDesignation() == Designation.EXECUTIVE && !account.getAssignedEmployee().equals(emp.getName())) {
	            throw new AccessDeniedException("Executives can only view transactions for assigned accounts");
	        }
        return transactionRepository.findByAccount(account);
	}



	public Map<String, BigDecimal> getTransactionSummary(int accountId, String empname) throws AccessDeniedException {
		
		 Employee emp = employeeRepository.findByUsername(empname)
	                .orElseThrow(() -> new RuntimeException("Employee not found"));

	        if (emp.getDesignation() != Designation.EXECUTIVE && emp.getDesignation() != Designation.MANAGER) {
	            throw new AccessDeniedException("Access denied for designation: " + emp.getDesignation());
	        }

	        
		Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new RuntimeException("Account not found"));


        if (emp.getDesignation() == Designation.EXECUTIVE && !account.getAssignedEmployee().equals(emp.getName())) {
            throw new AccessDeniedException("Executives can only view transactions summary for assigned accounts");
        }

        BigDecimal deposit = transactionRepository.sumAmountByAccountAndType(account, TxnType.DEPOSIT);
        BigDecimal withdraw = transactionRepository.sumAmountByAccountAndType(account, TxnType.WITHDRAW);
        BigDecimal transfer = transactionRepository.sumAmountByAccountAndType(account, TxnType.TRANSFER);

        BigDecimal inbound = deposit == null ? BigDecimal.ZERO : deposit;
        BigDecimal outbound = BigDecimal.ZERO
                .add(withdraw == null ? BigDecimal.ZERO : withdraw)
                .add(transfer == null ? BigDecimal.ZERO : transfer);

        Map<String, BigDecimal> summary = new HashMap<>();
        summary.put("inbound", inbound);
        summary.put("outbound", outbound);
        
        return summary;
	}



	public String closeAccount(int closureRequestId, String name) throws AccessDeniedException {
		
		 Employee emp = employeeRepository.findByUsername(name)
	                .orElseThrow(() -> new RuntimeException("Employee not found"));

	        if (emp.getDesignation() != Designation.MANAGER) {
	            throw new AccessDeniedException("Only Manager can close accounts");
	        }
		
		
		AccountClosureRequest request = ClosureRequestRepository.findById(closureRequestId)
                .orElseThrow(() -> new RuntimeException("Closure Request not found"));

		
		if (request.getStatus() != RequestStatus.PENDING) {
            throw new RuntimeException("Request already processed");
        }
		
        Account account = request.getAccount();
        account.setActive(false);
        accountRepository.save(account);

        request.setStatus(RequestStatus.APPROVED);
        request.setApprovedBy(emp.getName());
        ClosureRequestRepository.save(request);

        return "Account closed successfully by " + name;
	}



	public List<Loan >getPendingLoanApplications(String name) throws AccessDeniedException {
		 Employee emp = employeeRepository.findByUsername(name)
	                .orElseThrow(() -> new RuntimeException("Employee not found"));

	        if (emp.getDesignation() != Designation.EXECUTIVE && emp.getDesignation() != Designation.MANAGER) {
	            throw new AccessDeniedException("Access denied for designation: " + emp.getDesignation());
	        }

		return loanRepository.findByStatus(LoanStatus.PENDING);
	}



	public Object approveLoan(int loanId, String name) throws AccessDeniedException {
		
		Employee emp = employeeRepository.findByUsername(name)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        if (emp.getDesignation() != Designation.MANAGER) {
            throw new AccessDeniedException("Only MANAGER can approve loans");
        }

		 Loan loan = loanRepository.findById(loanId)
	                .orElseThrow(() -> new RuntimeException("Loan not found"));

	        if (!loan.getStatus().equals("PENDING")) {
	            throw new RuntimeException("Loan is not in PENDING state");
	        }

	        loan.setStatus(LoanStatus.APPROVED);
	        loan.setApprovedBy(emp);
	        loan.setApprovedDate(LocalDate.now());
	        loanRepository.save(loan);

	        return "Loan approved by " + name;
	}



	public String rejectLoan(int loanId, String name) throws AccessDeniedException {
		Employee emp = employeeRepository.findByUsername(name)
	            .orElseThrow(() -> new RuntimeException("Employee not found"));

	    if (emp.getDesignation() != Designation.MANAGER) {
	        throw new AccessDeniedException("Only Manager can reject loans");
	    }
		
		Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new RuntimeException("Loan not found"));

        if (!loan.getStatus().equals(LoanStatus.PENDING)) {
            throw new RuntimeException("Loan is not in Pending state");
        }

        loan.setStatus(LoanStatus.REJECTED);
        loan.setRejectedBy(emp);
        loan.setRejectedDate(LocalDate.now());
        loanRepository.save(loan);

        return "Loan rejected by " + name;
	}



	public String disburseLoan(int loanId, String name) throws AccessDeniedException {
        Employee emp = employeeRepository.findByUsername(name)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        if (emp.getDesignation() != Designation.MANAGER) {
            throw new AccessDeniedException("Only Manager can disburse loans");
        }

		Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new RuntimeException("Loan not found"));

        if (!loan.getStatus().equals(LoanStatus.APPROVED)) {
            throw new RuntimeException("Loan must be APPROVED to disburse");
        }

        loan.setStatus(LoanStatus.DISBURSED);
        loanRepository.save(loan);

        Account account = loan.getAccount();
        account.setBalance(account.getBalance().add(loan.getAmount()));
        accountRepository.save(account);

        return "Loan disbursed by " + name;
	}
	/*
	public Report generatePerformanceReport(String empname) throws AccessDeniedException {
		 Employee emp = employeeRepository.findByUsername(empname)
		            .orElseThrow(() -> new RuntimeException("Employee not found"));

		    if (emp.getDesignation() != Designation.MANAGER && emp.getDesignation() != Designation.SENIOR_MANAGER) {
		        throw new AccessDeniedException("Only MANAGER or above can generate performance reports");
		    }
        
       ReportDTO dto=  reportRepository.generatePerformanceReport(emp.getName());
    
       Report report=new Report();
       report.setManager(emp);
       report.setReportType(ReportType.PERFORMANCE);
       report.setGeneratedDate(LocalDate.now());
       report.setContent(dto.toString());
       
       return report;
	}

   
    public ReportDTO generateRegulatoryReport(String empname) {
        return reportRepository.generateRegulatoryReport(empname);
    }
    */
	
}
