package com.Hex.MaverickBank.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="account_statement")
public class AccountStatement {
    public int getStmtId() {
		return stmtId;
	}
	public void setStmtId(int stmtId) {
		this.stmtId = stmtId;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public LocalDate getPeriodFrom() {
		return periodFrom;
	}
	public void setPeriodFrom(LocalDate periodFrom) {
		this.periodFrom = periodFrom;
	}
	public LocalDate getPeriodTo() {
		return periodTo;
	}
	public void setPeriodTo(LocalDate periodTo) {
		this.periodTo = periodTo;
	}
	public LocalDateTime getGeneratedOn() {
		return generatedOn;
	}
	public void setGeneratedOn(LocalDateTime generatedOn) {
		this.generatedOn = generatedOn;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int stmtId;

    @ManyToOne
    @JoinColumn(name = "acc_id")
    private Account account;

    private LocalDate periodFrom;
    private LocalDate periodTo;
    private LocalDateTime generatedOn;
    private String filePath;
}


