package com.Hex.MaverickBank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.model.Grievance;

@Repository
public interface GrievanceRepository extends JpaRepository<Grievance, Integer>{

}
