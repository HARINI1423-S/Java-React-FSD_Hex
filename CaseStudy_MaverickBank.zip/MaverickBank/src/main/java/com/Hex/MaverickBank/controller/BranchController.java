package com.Hex.MaverickBank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Hex.MaverickBank.exception.IdNotFoundException;
import com.Hex.MaverickBank.model.Branch;
import com.Hex.MaverickBank.service.BranchService;

@RestController
@RequestMapping("/api/branches")
public class BranchController {
	
	@Autowired
	private BranchService branchService;
	
	@PostMapping("/create")
	public ResponseEntity<?> createBranch(@RequestBody Branch branch){
		return ResponseEntity.status(HttpStatus.OK).body(branchService.createBranch(branch));
	}
	
	@GetMapping("/get/{id}")
	public ResponseEntity<?> getBranchById(@PathVariable int id) throws IdNotFoundException{
		return ResponseEntity.status(HttpStatus.OK).body(branchService.getBranchById(id));
	}
	
	
	@GetMapping("/getAll")
	public ResponseEntity<?> getAllBranches(){
		return ResponseEntity.status(HttpStatus.OK).body(branchService.getAllBranches());
	}
	
	

}
