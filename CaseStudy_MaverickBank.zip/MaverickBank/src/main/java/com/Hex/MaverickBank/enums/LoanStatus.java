package com.Hex.MaverickBank.enums;

public enum LoanStatus {
	PENDING, APPROVED, REJECTED, DISBURSED
}
