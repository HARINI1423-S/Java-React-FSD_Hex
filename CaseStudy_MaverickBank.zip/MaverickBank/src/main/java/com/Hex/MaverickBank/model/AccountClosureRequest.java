package com.Hex.MaverickBank.model;

import java.time.LocalDate;

import com.Hex.MaverickBank.enums.RequestStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="account_closure_request")
public class AccountClosureRequest {
	
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @ManyToOne
	    private Account account;

	    private String reason;

	    private LocalDate requestedDate = LocalDate.now();

	    @Enumerated(EnumType.STRING)
	    private RequestStatus status = RequestStatus.PENDING;
	    
	    private String approvedBy;          
	    private LocalDate approvedDate;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Account getAccount() {
			return account;
		}
		public void setAccount(Account account) {
			this.account = account;
		}
		public String getReason() {
			return reason;
		}
		public void setReason(String reason) {
			this.reason = reason;
		}
		public LocalDate getRequestedDate() {
			return requestedDate;
		}
		public void setRequestedDate(LocalDate requestedDate) {
			this.requestedDate = requestedDate;
		}
		public RequestStatus getStatus() {
			return status;
		}
		public void setStatus(RequestStatus status) {
			this.status = status;
		}
		public String getApprovedBy() {
			return approvedBy;
		}
		public void setApprovedBy(String approvedBy) {
			this.approvedBy = approvedBy;
		}
		public LocalDate getApprovedDate() {
			return approvedDate;
		}
		public void setApprovedDate(LocalDate approvedDate) {
			this.approvedDate = approvedDate;
		}

		
   
	    
	    
}

