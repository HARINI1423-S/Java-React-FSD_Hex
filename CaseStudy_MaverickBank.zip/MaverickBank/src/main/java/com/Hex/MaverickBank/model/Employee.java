package com.Hex.MaverickBank.model;

import com.Hex.MaverickBank.enums.Designation;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {

	    
	    public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

		@Column(name = "employee_code", unique = true)
	    private String employeeCode;

	    
	    private String name;
	    private String contact;
	    private String email;
	    
	    @Enumerated(EnumType.STRING)
	    private Designation designation;
	    
	    @OneToOne
	    @JoinColumn(name = "user_id", referencedColumnName = "id")
	    private User user;
	    
	    @ManyToOne
	    @JoinColumn(name = "branch_id")
	    private Branch branch;

	    @ManyToOne
	    private Employee createdByManager;

		

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getContact() {
			return contact;
		}

		public void setContact(String contact) {
			this.contact = contact;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public Designation getDesignation() {
			return designation;
		}

		public void setDesignation(Designation designation) {
			this.designation = designation;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

		public Employee getCreatedByManager() {
			return createdByManager;
		}

		public void setCreatedByManager(Employee createdByManager) {
			this.createdByManager = createdByManager;
		}
		
		public Branch getBranch() {
	        return branch;
	    }

	    public void setBranch(Branch branch) {
	        this.branch = branch;
	    }
	    
	    
	   
	 }