package com.Hex.MaverickBank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.Hex.MaverickBank.exception.CustomAuthenticationEntryPoint;

@Configuration
public class SecurityConfig {
	
	  @Autowired
	    private CustomAuthenticationEntryPoint customEntryPoint;
	  @Autowired
	    private Jwtfilter jwtFilter;
	  
	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
		http
		.csrf(csrf -> csrf.disable())
		.authorizeHttpRequests(authorize->authorize
				//user
				.requestMatchers("/api/user/signup").permitAll()
				.requestMatchers("/api/user/register").permitAll()
				.requestMatchers("/api/user/token").permitAll()
				.requestMatchers("/api/user/get/{id}").authenticated()
				//branch
				.requestMatchers("/api/branches/create").hasAuthority("ROLE_MANAGER")
				.requestMatchers("/api/branches/get/{id}").hasAnyAuthority("ROLE_MANAGER","executive")
				.requestMatchers("/api/branches/getAll").hasAnyAuthority("ROLE_MANAGER")
				//account
				.requestMatchers("/api/account/Open").authenticated()
				.requestMatchers("/api/account/getByUsername").hasAnyAuthority("account_holder","manager","executive")
				.requestMatchers("/api/account/getById/{id}").hasAnyAuthority("account_holder","manager","executive")
				.requestMatchers("/api/account/get/active/{id}").hasAnyAuthority("manager","executive")
				.requestMatchers("/api/account/getBy/branchId/{id}").hasAnyAuthority("manager","executive")
				//account_holder
				.requestMatchers("/api/accountholders/create").hasAnyAuthority("account_holder","executive")
				.requestMatchers("/api/accountholders/get/profile").hasAnyAuthority("account_holder")
				.requestMatchers("/api/accountholders/getAll/accountholders").hasAnyAuthority("manager","executive")
				//accountCreateRequest
				.requestMatchers("/api/account/request/create").hasAnyAuthority("account_holder")
				.requestMatchers("/api/account/request/getAll").hasAnyAuthority("manager","executive")
				//accountClosureRequest
				.requestMatchers("/api/accounts/create/closure").hasAnyAuthority("account_holder")
				.requestMatchers("/api/accounts/getAll/closures").hasAnyAuthority("manager","executive")
				//transactions
				.requestMatchers("/api/transactions/deposit").hasAnyAuthority("account_holder")
				.requestMatchers("/api/transactions/withdraw").hasAnyAuthority("account_holder")
				.requestMatchers("/api/transactions/transfer").hasAnyAuthority("account_holder")
				.requestMatchers("/api/transactions/last10").hasAnyAuthority("account_holder")
				.requestMatchers("/api/transactions/between").hasAnyAuthority("manager","executive","account_holder")
				//manager
				.requestMatchers("/api/manager/create/employees").hasAuthority("ROLE_MANAGER")
				.requestMatchers("/api/manager/getAll/employees").hasAuthority("ROLE_MANAGER")
				.requestMatchers("/api/manager/profile").hasAuthority("ROLE_MANAGER")
				//beneficiary
				.requestMatchers("/api/beneficiary/add").hasAuthority("ROLE_MANAGER")
				.requestMatchers("api/beneficiary/get").hasAuthority("ROLE_MANAGER")
				
						.anyRequest().authenticated())
				.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class)
                              .httpBasic(httpBasic -> httpBasic.authenticationEntryPoint(customEntryPoint)); 
                             return http.build();
	}
	
	@Bean  
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
	AuthenticationManager getAuthManager(AuthenticationConfiguration auth) throws Exception {
		return auth.getAuthenticationManager();
		
	}
	
	
	

}
