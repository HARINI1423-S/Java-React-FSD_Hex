package com.Hex.MaverickBank.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Hex.MaverickBank.dto.CreateRequestDTO;
import com.Hex.MaverickBank.enums.AccountType;
import com.Hex.MaverickBank.model.AccountCreateRequest;
import com.Hex.MaverickBank.service.AccountCreateRequestService;

@RestController
@RequestMapping("/api/account/request")
public class AccountCreateRequestController {
	
	
	@Autowired
	private AccountCreateRequestService accountCreateRequestService;
	
	@PostMapping("/create")
    public ResponseEntity<?> create(@RequestBody CreateRequestDTO createRequestDTO,
            Principal principal	) {
		AccountType accountType=createRequestDTO.getAccountType();
		Integer branchId=createRequestDTO.getBranchId();
		String username=principal.getName();
        return accountCreateRequestService.create(accountType, branchId, username);
    }

    @GetMapping("/getAll")
    public List<AccountCreateRequest> getAll() {
        return accountCreateRequestService.getAll();
    }
}
