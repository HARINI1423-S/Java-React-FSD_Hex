package com.Hex.MaverickBank.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Hex.MaverickBank.model.AccountHolder;
import com.Hex.MaverickBank.service.AccountHolderService;

@RestController
@RequestMapping("/api/accountholders")
public class AccountHolderController {
	
	@Autowired
	private AccountHolderService accountHolderService;
	
	@PostMapping("/create")
	public ResponseEntity<?> create(@RequestBody AccountHolder accountHolder,Principal principal) {
		String username=principal.getName();
		return accountHolderService.createAccountHolder(accountHolder,username);
	}
	
	
	@GetMapping("/getAll/accountholders")
	public List<AccountHolder> getAllAccountHolders(){
		return accountHolderService.getAllAccountHolders();
	}
	
	
	@GetMapping("/get/profile")
	public ResponseEntity<?> getMyAccountHolderProfile(Principal principal){
		String username=principal.getName();
		return accountHolderService.getMyAccountHolderProfile(username);
	}
	
	
	
	

}
