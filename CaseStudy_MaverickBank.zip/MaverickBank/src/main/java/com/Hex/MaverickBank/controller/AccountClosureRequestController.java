package com.Hex.MaverickBank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Hex.MaverickBank.dto.ClosureRequestDTO;
import com.Hex.MaverickBank.model.AccountClosureRequest;
import com.Hex.MaverickBank.service.AccountClosureRequestService;

@RestController
@RequestMapping("/api/accounts")
public class AccountClosureRequestController {
	
	@Autowired
	private AccountClosureRequestService service;

    public AccountClosureRequestController(AccountClosureRequestService service) {
        this.service = service;
    }

    @PostMapping("/create/closure")
    public ResponseEntity<?> createClosure(@RequestBody ClosureRequestDTO dto) {
        return service.create(dto); 
    }

    @GetMapping("/getAll/closures")
    public List<AccountClosureRequest> getAll() {
        return service.getAll();
    }

}
