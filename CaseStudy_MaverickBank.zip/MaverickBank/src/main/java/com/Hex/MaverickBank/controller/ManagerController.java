package com.Hex.MaverickBank.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Hex.MaverickBank.dto.EmployeeCreateRequest;
import com.Hex.MaverickBank.model.Employee;
import com.Hex.MaverickBank.service.ManagerService;

@RestController
@RequestMapping("/api/manager")
public class ManagerController {
	@Autowired
	private ManagerService managerService;
	
	@PostMapping("create/employees")
    public ResponseEntity<?> createEmployee(@RequestBody EmployeeCreateRequest request, Principal principal) {
		String name=principal.getName();
        return managerService.createEmployee(request,name); 
    }

    @GetMapping("getAll/employees")
    public ResponseEntity<List<Employee>> getAllEmployees(Principal principal) {
    	String name=principal.getName();
        return ResponseEntity.status(HttpStatus.OK).body(managerService.getAllEmployees(name));
    }

    @GetMapping("/profile")
    public ResponseEntity<Employee> getProfile(Principal principal) {
    	String name=principal.getName();
        return ResponseEntity.status(HttpStatus.OK).body(managerService.getProfile(name));
    }
}
