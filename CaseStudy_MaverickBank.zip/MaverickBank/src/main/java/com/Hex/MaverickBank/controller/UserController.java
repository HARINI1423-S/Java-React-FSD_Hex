package com.Hex.MaverickBank.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Hex.MaverickBank.exception.AccessDeniedException;
import com.Hex.MaverickBank.exception.UserNotFoundException;
import com.Hex.MaverickBank.model.User;
import com.Hex.MaverickBank.service.UserService;
import com.Hex.MaverickBank.util.JwtUtil;

@RestController
@RequestMapping("/api/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	
	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@RequestBody User user) throws AccessDeniedException{
		return ResponseEntity.status(HttpStatus.OK).body(userService.SignUp(user));
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<?> getUserById(@PathVariable int id) throws UserNotFoundException{
		return ResponseEntity.status(HttpStatus.OK).body(userService.getUserById(id));
		
	}
	@GetMapping("/token")
	public String getToken(Principal principal) {
		String token =jwtUtil.createToken(principal.getName());
		return token;
		
	}

}
