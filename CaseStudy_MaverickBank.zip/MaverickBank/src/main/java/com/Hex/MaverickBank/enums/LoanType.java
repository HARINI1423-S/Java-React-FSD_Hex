package com.Hex.MaverickBank.enums;

public enum LoanType {
	PERSONAL, HOME, AUTOMOBILE, CORPORATE
}
