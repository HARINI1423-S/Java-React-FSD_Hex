package com.Hex.MaverickBank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.model.InternetBanking;

@Repository
public interface InternetBankingRepository extends JpaRepository<InternetBanking, Integer> {

}
