package com.Hex.MaverickBank.enums;

public enum Designation {
	EXECUTIVE,             
    LOAN_EXECUTIVE,        
    ACCOUNT_EXECUTIVE,     
    MANAGER,               
    SENIOR_MANAGER,        
    REGIONAL_HEAD          
	    }
