package com.Hex.MaverickBank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.model.AccountClosureRequest;

@Repository
public interface AccountClosureRequestRepository extends JpaRepository<AccountClosureRequest, Integer> {

}
