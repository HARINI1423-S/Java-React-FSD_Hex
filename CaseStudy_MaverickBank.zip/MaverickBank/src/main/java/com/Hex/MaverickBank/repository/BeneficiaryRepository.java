package com.Hex.MaverickBank.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.model.Beneficiary;

@Repository
public interface BeneficiaryRepository extends JpaRepository<Beneficiary, Integer> {

	@Query("SELECT b from Beneficiary b where b.account.id=?1")
	List<Beneficiary> findByAccountId(Long id);

}
