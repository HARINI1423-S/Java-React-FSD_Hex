
package com.Hex.MaverickBank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.model.Card;

@Repository
public interface CardRepository extends JpaRepository<Card, Integer>{

}
