package com.Hex.MaverickBank.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.model.Manager;

@Repository
public interface ManagerRepository extends JpaRepository<Manager, Integer> {

}
