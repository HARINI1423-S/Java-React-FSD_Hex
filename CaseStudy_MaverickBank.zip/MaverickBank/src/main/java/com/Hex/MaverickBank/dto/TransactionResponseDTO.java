package com.Hex.MaverickBank.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TransactionResponseDTO {
	
	 private Long transactionId;
	    private String type;
	    private BigDecimal amount;
	    private LocalDateTime timestamp;
	    private String description;
	    private String referenceAccount;
	    private Long accountId;
	    private String accountType;
	    private BigDecimal availableBalance;
//	    
//		public TransactionResponseDTO(Long transactionId, String type, BigDecimal amount, LocalDateTime timestamp,
//				String description, String referenceAccount, Long accountId, String accountType,
//				BigDecimal availableBalance) {
//			super();
//			this.transactionId = transactionId;
//			this.type = type;
//			this.amount = amount;
//			this.timestamp = timestamp;
//			this.description = description;
//			this.referenceAccount = referenceAccount;
//			this.accountId = accountId;
//			this.accountType = accountType;
//			this.availableBalance = availableBalance;
//		}
//		
		public Long getTransactionId() {
			return transactionId;
		}
		public void setTransactionId(Long transactionId) {
			this.transactionId = transactionId;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public BigDecimal getAmount() {
			return amount;
		}
		public void setAmount(BigDecimal amount) {
			this.amount = amount;
		}
		public LocalDateTime getTimestamp() {
			return timestamp;
		}
		public void setTimestamp(LocalDateTime timestamp) {
			this.timestamp = timestamp;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getReferenceAccount() {
			return referenceAccount;
		}
		public void setReferenceAccount(String referenceAccount) {
			this.referenceAccount = referenceAccount;
		}
		public Long getAccountId() {
			return accountId;
		}
		public void setAccountId(Long accountId) {
			this.accountId = accountId;
		}
		public String getAccountType() {
			return accountType;
		}
		public void setAccountType(String accountType) {
			this.accountType = accountType;
		}
		public BigDecimal getAvailableBalance() {
			return availableBalance;
		}
		public void setAvailableBalance(BigDecimal availableBalance) {
			this.availableBalance = availableBalance;
		}
	    
	    

}
