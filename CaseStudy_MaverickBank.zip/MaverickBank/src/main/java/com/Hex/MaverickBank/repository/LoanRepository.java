package com.Hex.MaverickBank.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.enums.LoanStatus;
import com.Hex.MaverickBank.model.Loan;

@Repository
public interface LoanRepository extends JpaRepository<Loan, Integer>{

	
	@Query("SELECT l FROM Loan l WHERE l.status=?1")
	List<Loan> findByStatus(LoanStatus status);

}
