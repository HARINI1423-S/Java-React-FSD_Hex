package com.Hex.MaverickBank.enums;

public enum RequestStatus {
	PENDING,
    APPROVED,
    REJECTED,
    CLOSED
}
