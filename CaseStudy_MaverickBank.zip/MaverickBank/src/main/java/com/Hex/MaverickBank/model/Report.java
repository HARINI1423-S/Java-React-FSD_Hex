package com.Hex.MaverickBank.model;

import java.time.LocalDate;

import com.Hex.MaverickBank.enums.ReportType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="report")
public class Report {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int id;

	    @ManyToOne
	    @JoinColumn(name = "manager_id", nullable = false)
	    private Employee manager;

	    @Enumerated(EnumType.STRING)
	    @Column(nullable = false)
	    private ReportType reportType;

	    @Column(nullable = false)
	    private LocalDate generatedDate;

	    @Column(length = 2000) 
	    private String content;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public Employee getManager() {
			return manager;
		}

		public void setManager(Employee manager) {
			this.manager = manager;
		}

		public ReportType getReportType() {
			return reportType;
		}

		public void setReportType(ReportType reportType) {
			this.reportType = reportType;
		}

		public LocalDate getGeneratedDate() {
			return generatedDate;
		}

		public void setGeneratedDate(LocalDate generatedDate) {
			this.generatedDate = generatedDate;
		}

		public String getContent() {
			return content;
		}

		public void setContent(String content) {
			this.content = content;
		}
	    
	    
    
   
   
}
