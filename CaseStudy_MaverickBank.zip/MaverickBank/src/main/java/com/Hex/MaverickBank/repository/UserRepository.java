package com.Hex.MaverickBank.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.enums.Role;
import com.Hex.MaverickBank.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{

	
	@Query("select u from User u where u.username=?1")
	User getUserName(String username);

	@Query("select u from User u where u.username=?1")
	Optional<User> findByUsername(String username);

	
	boolean existsByUsername(String username);

	@Query("SELECT u FROM User u WHERE u.role = ?1")
    List<User> findUsersByRole(Role role);



}
