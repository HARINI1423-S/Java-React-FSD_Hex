package com.Hex.MaverickBank.dto;

import com.Hex.MaverickBank.enums.Designation;

public class EmployeeCreateRequest {
	private int userId;
	private String name;
    private String contact;
    private Designation designation;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public Designation getDesignation() {
		return designation;
	}
	public void setDesignation(Designation designation) {
		this.designation = designation;
	}
   
	
    
}
