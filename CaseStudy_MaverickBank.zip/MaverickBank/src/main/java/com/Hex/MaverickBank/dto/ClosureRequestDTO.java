package com.Hex.MaverickBank.dto;

public class ClosureRequestDTO {
	private Integer accountId;
    private String reason;
	public Integer getAccountId() {
		return accountId;
	}
	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	
    
    
	  
	

}
