package com.Hex.MaverickBank.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.Hex.MaverickBank.enums.AccountType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="account")
public class Account {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	 	@Column(nullable = false)
	    @Enumerated(EnumType.STRING)
	    private AccountType accountType;

	    @ManyToOne
	    @JoinColumn(name = "account_holder_id")
	    private AccountHolder accountHolder;

	    private BigDecimal balance = BigDecimal.ZERO;

	    private LocalDate openedDate = LocalDate.now();
	    
	    @ManyToOne
	    @JoinColumn(name = "branch_id")
	    private Branch branch;

	    private String ifscCode;
	    private boolean isActive = true;
	    
	    @ManyToOne
	    @JoinColumn(name = "employee_id")
	    private Employee assignedEmployee;

	    // getters and setters
	    public Employee getAssignedEmployee() {
	        return assignedEmployee;
	    }

	    public void setAssignedEmployee(Employee assignedEmployee) {
	        this.assignedEmployee = assignedEmployee;
	    }
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public AccountType getAccountType() {
			return accountType;
		}
		public void setAccountType(AccountType accountType) {
			this.accountType = accountType;
		}
		public AccountHolder getAccountHolder() {
			return accountHolder;
		}
		public void setAccountHolder(AccountHolder accountHolder) {
			this.accountHolder = accountHolder;
		}
		public BigDecimal getBalance() {
			return balance;
		}
		public void setBalance(BigDecimal balance) {
			this.balance = balance;
		}
		public LocalDate getOpenedDate() {
			return openedDate;
		}
		public void setOpenedDate(LocalDate openedDate) {
			this.openedDate = openedDate;
		}
		public Branch getBranch() {
			return branch;
		}
		public void setBranch(Branch branch) {
			this.branch = branch;
		}
		public String getIfscCode() {
			return ifscCode;
		}
		public void setIfscCode(String ifscCode) {
			this.ifscCode = ifscCode;
		}
		public boolean isActive() {
			return isActive;
		}
		public void setActive(boolean isActive) {
			this.isActive = isActive;
		}
	    
	    
   
}
