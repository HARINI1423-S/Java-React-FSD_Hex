package com.Hex.MaverickBank.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.Hex.MaverickBank.enums.InvestmentStatus;
import com.Hex.MaverickBank.enums.InvestmentType;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="investment")
public class Investment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int invId;

    @ManyToOne
    @JoinColumn(name = "acc_id")
    private Account account;

    @Enumerated(EnumType.STRING)
    private InvestmentType type;

    private BigDecimal amount;
    private LocalDate startDate;
    private LocalDate maturityDate;
    private BigDecimal interestRate;

    @Enumerated(EnumType.STRING)
    private InvestmentStatus status;

	public int getInvId() {
		return invId;
	}

	public void setInvId(int invId) {
		this.invId = invId;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public InvestmentType getType() {
		return type;
	}

	public void setType(InvestmentType type) {
		this.type = type;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(LocalDate maturityDate) {
		this.maturityDate = maturityDate;
	}

	public BigDecimal getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}

	public InvestmentStatus getStatus() {
		return status;
	}

	public void setStatus(InvestmentStatus status) {
		this.status = status;
	}

    
}
