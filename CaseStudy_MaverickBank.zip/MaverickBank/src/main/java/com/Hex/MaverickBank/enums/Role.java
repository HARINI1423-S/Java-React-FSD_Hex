package com.Hex.MaverickBank.enums;

public enum Role {
	    account_holder,
	    executive,
	    manager, regional_manager
	}


