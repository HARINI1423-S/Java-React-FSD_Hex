package com.Hex.MaverickBank.enums;

public enum LoanEscalationStatus {
	ESCALATED,
    OVERRIDDEN,
    CLOSED
}
