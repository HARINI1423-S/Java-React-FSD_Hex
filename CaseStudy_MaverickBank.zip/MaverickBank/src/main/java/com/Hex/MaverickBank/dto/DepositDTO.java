package com.Hex.MaverickBank.dto;

import java.math.BigDecimal;

public class DepositDTO {
	 private BigDecimal amount;

     // Getter and setter
     public BigDecimal getAmount() {
         return amount;
     }
     public void setAmount(BigDecimal amount) {
         this.amount = amount;
     }
}
