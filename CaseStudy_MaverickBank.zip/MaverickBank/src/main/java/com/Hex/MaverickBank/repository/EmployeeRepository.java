package com.Hex.MaverickBank.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.model.Employee;
import com.Hex.MaverickBank.model.User;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	
	@Query("SELECT e FROM Employee e WHERE e.user = :user")
	Optional<Employee> findByUser(User user);

	
	@Query("SELECT e FROM Employee e WHERE e.createdByManager = :manager")
	List<Employee> findByManager(Employee manager);


	@Query("SELECT e FROM Employee e WHERE e.name=?1")
	Optional<Employee> findByUsername(String empname);

}
