package com.Hex.MaverickBank.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.Hex.MaverickBank.enums.TxnType;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="transaction")
public class Transaction {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @ManyToOne
	    @JoinColumn(name = "account_id")
	    private Account account;

	    @Enumerated(EnumType.STRING)
	    private TxnType type; 
	    
	    private BigDecimal amount;
	    
	    private String description;
	    private LocalDateTime timestamp = LocalDateTime.now();
	    private String referenceAccount;
	    
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Account getAccount() {
			return account;
		}
		public void setAccount(Account account) {
			this.account = account;
		}
		public TxnType getType() {
			return type;
		}
		public void setType(TxnType type) {
			this.type = type;
		}
		public BigDecimal getAmount() {
			return amount;
		}
		public void setAmount(BigDecimal amount) {
			this.amount = amount;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public LocalDateTime getTimestamp() {
			return timestamp;
		}
		public void setTimestamp(LocalDateTime timestamp) {
			this.timestamp = timestamp;
		}
		public String getReferenceAccount() {
			return referenceAccount;
		}
		public void setReferenceAccount(String referenceAccount) {
			this.referenceAccount = referenceAccount;
		}
	
	    
	    
}
