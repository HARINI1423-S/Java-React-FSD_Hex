package com.Hex.MaverickBank.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoanController {

}
