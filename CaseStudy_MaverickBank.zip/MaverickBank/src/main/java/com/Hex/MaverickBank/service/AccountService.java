package com.Hex.MaverickBank.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.exception.BranchNotFoundException;
import com.Hex.MaverickBank.exception.IdNotFoundException;
import com.Hex.MaverickBank.exception.UserNotFoundException;
import com.Hex.MaverickBank.model.Account;
import com.Hex.MaverickBank.model.AccountHolder;
import com.Hex.MaverickBank.model.Branch;
import com.Hex.MaverickBank.model.User;
import com.Hex.MaverickBank.repository.AccountHolderRepository;
import com.Hex.MaverickBank.repository.AccountRepository;
import com.Hex.MaverickBank.repository.BranchRepository;
import com.Hex.MaverickBank.repository.UserRepository;

@Service
public class AccountService {
	
	private AccountRepository accountRepository;
	private AccountHolderRepository accountHolderRepository;
	private BranchRepository branchRepository;
    private  UserRepository userRepository;
    

	public AccountService(AccountRepository accountRepository, AccountHolderRepository accountHolderRepository,
			BranchRepository branchRepository, UserRepository userRepository) {
		super();
		this.accountRepository = accountRepository;
		this.accountHolderRepository = accountHolderRepository;
		this.branchRepository = branchRepository;
		this.userRepository = userRepository;
	}


	public ResponseEntity<?> createAccount(Account account, String username) throws UserNotFoundException, BranchNotFoundException, IdNotFoundException {
		 User user = userRepository.findByUsername(username)
			        .orElseThrow(() -> new UserNotFoundException("User not found"));

			    // Step 2: Check if AccountHolder exists for this user
		 Optional<AccountHolder> chkaccountHolder = accountHolderRepository.findByUsername(user.getUsername());

			    if (chkaccountHolder.isEmpty()) {
			        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Please create an AccountHolder profile first.");
			    }
	  
	   AccountHolder accountHolder=chkaccountHolder.get();
	   
	   boolean accountTypeExist=accountRepository.existsAccountType(accountHolder,account.getAccountType());
	   if(accountTypeExist) {
		   return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Account Type already exists for this accountHolder");
	   }
	   
	   Optional<Branch> Existbranch = branchRepository.findById(account.getBranch().getId());
	    if (Existbranch.isEmpty()) {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid branch ID.");
	    }
	   
	    Branch branch=Existbranch.get();
	    
	    Account addAccount=new Account();
	    addAccount.setAccountType(account.getAccountType());
	    addAccount.setBalance(account.getBalance());
	    addAccount.setOpenedDate(LocalDate.now());
	    addAccount.setBranch(branch);
	    addAccount.setIfscCode(branch.getIfsc());
	    addAccount.setAccountHolder(accountHolder);
	    addAccount.setActive(true);
	    
	    Account saveAccount=accountRepository.save(addAccount);
	    return ResponseEntity.status(HttpStatus.CREATED).body("Account Created Successfully");
	    
	    }



	public List<Account> getMyAccounts(String username) {
		// TODO Auto-generated method stub
		return accountRepository.getMyAccounts(username);
	}



	public List<Account> getAccountById(Long id) {
		// TODO Auto-generated method stub
		return accountRepository.findByAccountHolderId(id);
	}



	public List<Account> getActiveAccounts(Long accountHolderId) {
		// TODO Auto-generated method stub
		return accountRepository.findActiveAccountsByAccountHolderId(accountHolderId);
	}


	public List<Account> findByBranchId(int id) {
		return accountRepository.findByBranchId(id);
	}


	public Object findByIfscCode(String ifscCode) {
		return accountRepository.findByIfscCode(ifscCode);
	}
	
	
	

}
