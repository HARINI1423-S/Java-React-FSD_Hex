package com.Hex.MaverickBank.exception;

public class InSufficientBalanceException extends Exception {

	private static final long serialVersionUID = 1L;

	private String message;

	public InSufficientBalanceException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
