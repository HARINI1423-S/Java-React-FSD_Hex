package com.Hex.MaverickBank.service;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.repository.UserRepository;

@Service
public class CustomUserServiceDetails implements UserDetailsService {
	
	 @Autowired
	    private UserRepository userRepository;

	    @Override
	    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	        com.Hex.MaverickBank.model.User user = userRepository.getUserName(username);

	        if (user == null) {
	            throw new UsernameNotFoundException("User not found: " + username);
	        }


	        String role = (user.getRole() != null) ? user.getRole().name().toUpperCase() : "USER";
	        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_" + role));



	        return new User(user.getUsername(), user.getPassword(), authorities);
	
	

}
}
