package com.Hex.MaverickBank.enums;

public enum InvestmentType {
	FD,
    RD,
    MUTUAL_FUND,
    BONDS,
    STOCKS

}
