package com.Hex.MaverickBank.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Hex.MaverickBank.exception.BranchNotFoundException;
import com.Hex.MaverickBank.exception.IdNotFoundException;
import com.Hex.MaverickBank.exception.UserNotFoundException;
import com.Hex.MaverickBank.model.Account;
import com.Hex.MaverickBank.service.AccountService;
import com.Hex.MaverickBank.service.UserService;

@RestController
@RequestMapping("/api/account")
public class AccountController {
	
	
	@Autowired
	private AccountService accountService;
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/Open")
	public ResponseEntity<?> create(@RequestBody Account account,Principal principal) throws UserNotFoundException, BranchNotFoundException, IdNotFoundException {
        String username=principal.getName();
		return ResponseEntity.status(HttpStatus.CREATED).body(accountService.createAccount(account,username));
    }
	
	
	@GetMapping("/getByUsername")
	public ResponseEntity<?> getMyAccounts(Principal principal){
		String username=principal.getName();	
		return ResponseEntity.status(HttpStatus.OK).body(accountService.getMyAccounts(username));
		
	}
	
	@GetMapping("/getById/{id}")
	public ResponseEntity<?> getMyAccountsById(@PathVariable Long id){
		return ResponseEntity.status(HttpStatus.OK).body(accountService.getAccountById(id));
	}
	
	@GetMapping("/get/active/{accountHolderId}")
	public List<Account> getActiveAccounts(@PathVariable Long accountHolderId){
		return accountService.getActiveAccounts(accountHolderId);
	}
	
	@GetMapping("/getBy/branchId/{id}")
	public ResponseEntity<?> findByBranchId(@PathVariable int id){
		return ResponseEntity.status(HttpStatus.OK).body(accountService.findByBranchId(id));
	}
	
	@GetMapping("/getBy/ifsc/{code}")
	public ResponseEntity<?> findByIfscCode(@PathVariable String ifscCode){
		return ResponseEntity.status(HttpStatus.OK).body(accountService.findByIfscCode(ifscCode));
	}
	
	
	
	
	

	

}
