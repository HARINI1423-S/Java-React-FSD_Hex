package com.Hex.MaverickBank.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.model.AccountHolder;
import com.Hex.MaverickBank.model.User;

@Repository
public interface AccountHolderRepository extends JpaRepository<AccountHolder, Integer>{

//	Optional<AccountHolder> existsByUser(User user);

	

	@Query("select ah from AccountHolder ah where ah.user.username=?1")
	Optional<AccountHolder> findByUsername(String username);



	

	

}
