package com.Hex.MaverickBank.repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.enums.TxnType;
import com.Hex.MaverickBank.model.Account;
import com.Hex.MaverickBank.model.Transaction;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Integer> {

	
	@Query("select t from  Transaction t where t.account.id=:accountId ORDER BY t.timestamp DESC")
	List<Transaction> getLast10Transactions(Long accountId, PageRequest limit);

	@Query("SELECT t FROM Transaction t WHERE t.account.id = :accountId AND t.timestamp BETWEEN :from AND :to")
	List<Transaction> getTransactionBetweenDates( Long accountId,LocalDateTime from,LocalDateTime to);

	

//	BigDecimal sumAmountByAccountAndType(Account account, String string);

	@Query("SELECT t FROM Transaction t WHERE t.account=?1")
	List<Transaction> findByAccount(Account account);

	@Query("SELECT SUM(t.amount) FROM Transaction t WHERE t.account = :account AND t.type = :type")
	BigDecimal sumAmountByAccountAndType(@Param("account") Account account, @Param("type") TxnType type);


}
