package com.Hex.MaverickBank.controller;

import java.math.BigDecimal;
import java.nio.file.AccessDeniedException;
import java.security.Principal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Hex.MaverickBank.exception.IdNotFoundException;
import com.Hex.MaverickBank.model.Account;
import com.Hex.MaverickBank.model.Loan;
import com.Hex.MaverickBank.model.Report;
import com.Hex.MaverickBank.model.Transaction;
import com.Hex.MaverickBank.repository.AccountRepository;
import com.Hex.MaverickBank.service.EmployeeService;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private AccountRepository accountRepository;
	
	
	
	@PostMapping("/approve/accountRequest/{requestId}")
	public ResponseEntity<?> approveAccount(@PathVariable Long requestId ,Principal principal) throws IdNotFoundException, AccessDeniedException{
		String username=principal.getName();
		return ResponseEntity.status(HttpStatus.OK).body(employeeService.approveAccount(requestId,username));
	}
	
	
	 @PostMapping("/reject/account/{requestId}")
	    public ResponseEntity<String> rejectAccount(@PathVariable int requestId, Principal principal) throws AccessDeniedException {
	        return ResponseEntity.ok(employeeService.rejectAccount(requestId, principal.getName()));
	    }

	    @GetMapping("/accounts")
	    public ResponseEntity<List<Account>> getAllAccounts(Principal principal) throws AccessDeniedException {
	    	String empname=principal.getName();
	        return ResponseEntity.ok(employeeService.getAllAccounts(empname));
	    }

	    @GetMapping("/transactions/{accountId}")
	    public ResponseEntity<List<Transaction>> getTransactionsByAccountId(@PathVariable int accountId, Principal principal) throws AccessDeniedException {
	    	String empname=principal.getName();
	        return ResponseEntity.ok(employeeService.getTransactionsByAccountId(accountId, empname));
	    }

	    @GetMapping("/transaction-summary/{accountId}")
	    public ResponseEntity<Map<String, BigDecimal>> getTransactionSummary(@PathVariable int accountId, Principal principal) throws AccessDeniedException {
	        return ResponseEntity.ok(employeeService.getTransactionSummary(accountId, principal.getName()));
	    }

	    @PostMapping("/close-account/{closureRequestId}")
	    public ResponseEntity<String> closeAccount(@PathVariable int closureRequestId, Principal principal) throws AccessDeniedException {
	        return ResponseEntity.ok(employeeService.closeAccount(closureRequestId, principal.getName()));
	    }

	    @GetMapping("/pending-loans")
	    public ResponseEntity<List<Loan>> getPendingLoanApplications(Principal principal) throws AccessDeniedException {
	        return ResponseEntity.ok(employeeService.getPendingLoanApplications(principal.getName()));
	    }

	    @PostMapping("/approve-loan/{loanId}")
	    public ResponseEntity<?> approveLoan(@PathVariable int loanId, Principal principal) throws AccessDeniedException {
	        return ResponseEntity.ok(employeeService.approveLoan(loanId, principal.getName()));
	    }

	    @PostMapping("/reject-loan/{loanId}")
	    public ResponseEntity<String> rejectLoan(@PathVariable int loanId, Principal principal) throws AccessDeniedException {
	        return ResponseEntity.ok(employeeService.rejectLoan(loanId, principal.getName()));
	    }

	    @PostMapping("/disburse-loan/{loanId}")
	    public ResponseEntity<?> disburseLoan(@PathVariable int loanId, Principal principal) throws AccessDeniedException {
	        return ResponseEntity.ok(employeeService.disburseLoan(loanId, principal.getName()));
	    }
/*
	    @GetMapping("/performance-report")
	    public ResponseEntity<?> generatePerformanceReport(Principal principal) throws AccessDeniedException {
	    	String empname=principal.getName();
	        return ResponseEntity.ok(employeeService.generatePerformanceReport(empname));
	    }

	    @GetMapping("/regulatory-report")
	    public ResponseEntity<?> generateRegulatoryReport(Principal principal) {
	    	String empname=principal.getName();
	        return ResponseEntity.ok(employeeService.generateRegulatoryReport(empname));
	    }

	 */  
	
	

}

