package com.Hex.MaverickBank.exception;

public class IdNotFoundException extends Exception {

	/**
	 * 
	 */
	private static long serialVersionUID = 1L;
	
	private String message;

	public IdNotFoundException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	} 
	

}
