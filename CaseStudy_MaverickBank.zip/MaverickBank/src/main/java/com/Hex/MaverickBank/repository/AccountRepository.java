package com.Hex.MaverickBank.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.enums.AccountType;
import com.Hex.MaverickBank.model.Account;
import com.Hex.MaverickBank.model.AccountHolder;
import com.Hex.MaverickBank.model.User;

@Repository
public interface AccountRepository extends JpaRepository<Account,Integer>{

	@Query("select a from Account a where accountHolder.user.username=?1 ")
	List<Account> getMyAccounts(String username);

	@Query("SELECT a FROM Account a WHERE a.accountHolder.id = :accountHolderId")
	List<Account> findByAccountHolderId( Long accountHolderId);
	
	@Query("SELECT a FROM Account a WHERE a.accountHolder.id = :accountHolderId AND a.isActive = true")
	List<Account> findActiveAccountsByAccountHolderId(Long accountHolderId);

	@Query("SELECT a FROM Account a WHERE a.branch.id = :branchId")
	List<Account> findByBranchId(int branchId);

	@Query("SELECT a FROM Account a WHERE a.ifscCode = :ifscCode")
	List<Account> findByIfscCode(String ifscCode);

	@Query("SELECT COUNT(a) > 0 FROM Account a WHERE a.accountHolder = :accountHolder AND a.accountType = :accountType")
	boolean existsAccountType(AccountHolder accountHolder, AccountType accountType);

	@Query("SELECT a FROM Account a WHERE a.accountHolder.user = :user")
	Optional<Account> findByUser(User user);

	
	Optional<Account> findByAccountHolderUserUsername(String username);

	@Query("SELECT a FROM Account a WHERE a.accountHolder.user.id = ?1")
	Optional<Account> findByAccountHolderId(@Param("Id")int id);

	@Query("SELECT a FROM Account a WHERE a.assignedEmployee=?1")
	List<Account> findByAssignedEmployee(String empname);


	

}
