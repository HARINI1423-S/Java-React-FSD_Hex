package com.Hex.MaverickBank.service;

import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.enums.Designation;
import com.Hex.MaverickBank.enums.Role;
import com.Hex.MaverickBank.exception.AccessDeniedException;
import com.Hex.MaverickBank.exception.UserNotFoundException;
import com.Hex.MaverickBank.model.Employee;
import com.Hex.MaverickBank.model.User;
import com.Hex.MaverickBank.repository.EmployeeRepository;
import com.Hex.MaverickBank.repository.UserRepository;

@Service
public class UserService {

	 private final UserRepository userRepository;
	    private final PasswordEncoder passwordEncoder;
	    private final EmployeeRepository employeeRepository;

	    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder,
	                       EmployeeRepository employeeRepository) {
	        this.userRepository = userRepository;
	        this.passwordEncoder = passwordEncoder;
	        this.employeeRepository = employeeRepository;
	    }

	    public ResponseEntity<?> SignUp(User user) throws AccessDeniedException {
	        if (userRepository.existsByUsername(user.getUsername())) {
	            return ResponseEntity.badRequest().body("Username already taken.");
	        }

	        user.setPassword(passwordEncoder.encode(user.getPassword()));

	        if (user.getRole() == null || user.getRole() == Role.account_holder) {
	            user.setRole(Role.account_holder);
	            userRepository.save(user);
	            return ResponseEntity.ok("Signup successful. Please complete your KYC to become an account holder.");
	        }

	        if (user.getRole() == Role.executive || user.getRole() == Role.manager) {
	            userRepository.save(user);

	            Employee employee = new Employee();
	            employee.setUser(user);
	            employee.setName(user.getUsername());
	            employee.setEmail(user.getUsername());

	            Designation designation = user.getRole() == Role.manager ? Designation.MANAGER : Designation.EXECUTIVE;
	            employee.setDesignation(designation);

	            String employeeCode = generateEmployeeCode(designation);
	            employee.setEmployeeCode(employeeCode);

	            employeeRepository.save(employee);

	            return ResponseEntity.ok("Signup successful as " + user.getRole());
	        }

	        return ResponseEntity.badRequest().body("Invalid or restricted role.");
	    }

	    public String generateEmployeeCode(Designation designation) {
	        long count = employeeRepository.countByDesignation(designation) + 1;
	        String prefix = (designation == Designation.MANAGER || designation == Designation.SENIOR_MANAGER) ? "MNGR" : "EMP";
	        return String.format("%s%03d", prefix, count);
	    }

	    public User getUserById(int id) throws UserNotFoundException {
	        return userRepository.findById(id)
	                .orElseThrow(() -> new UserNotFoundException("User with given ID not found"));
	    }
}
