package com.Hex.MaverickBank.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Hex.MaverickBank.model.Report;
import com.Hex.MaverickBank.service.ReportService;

@RestController
@RequestMapping("/api/reports")
public class ReportController {
	
	/* @Autowired
    private ReportService reportService;

    @GetMapping("/performance")
    public ResponseEntity<?> getPerformanceReport(Principal principal) throws AccessDeniedException {
        String name=principal.getName();
    	return ResponseEntity.ok(reportService.generatePerformanceReport(name));
    }

    @GetMapping("/regulatory")
    public ResponseEntity<?> getRegulatoryReport(@RequestParam String empname) {

    	return ResponseEntity.ok(reportService.generateRegulatoryReport(empname));
    }
*/
}
