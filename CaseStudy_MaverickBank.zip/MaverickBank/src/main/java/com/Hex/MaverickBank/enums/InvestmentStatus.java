package com.Hex.MaverickBank.enums;

public enum InvestmentStatus {
	 ACTIVE,
     MATURED,
     CLOSED
}
