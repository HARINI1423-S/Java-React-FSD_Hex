package com.Hex.MaverickBank.dto;

import com.Hex.MaverickBank.enums.AccountType;

public class CreateRequestDTO {
	
	 private AccountType accountType;
	    private Integer branchId;
	    
		public AccountType getAccountType() {
			return accountType;
		}
		public void setAccountType(AccountType accountType) {
			this.accountType = accountType;
		}
		public Integer getBranchId() {
			return branchId;
		}
		public void setBranchId(Integer branchId) {
			this.branchId = branchId;
		}
	    

}
