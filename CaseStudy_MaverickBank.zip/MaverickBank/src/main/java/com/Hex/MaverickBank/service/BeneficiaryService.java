package com.Hex.MaverickBank.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.model.Account;
import com.Hex.MaverickBank.model.Beneficiary;
import com.Hex.MaverickBank.model.User;
import com.Hex.MaverickBank.repository.AccountRepository;
import com.Hex.MaverickBank.repository.BeneficiaryRepository;
import com.Hex.MaverickBank.repository.UserRepository;

@Service
public class BeneficiaryService {
	
	private BeneficiaryRepository beneficiaryRepository;
	private UserRepository userRepository;
	private AccountRepository accountRepository;
	

	public BeneficiaryService(BeneficiaryRepository beneficiaryRepository, UserRepository userRepository,
			AccountRepository accountRepository) {
		super();
		this.beneficiaryRepository = beneficiaryRepository;
		this.userRepository = userRepository;
		this.accountRepository = accountRepository;
	}

	public List<Beneficiary> getBeneficiary(Long id) {
		return beneficiaryRepository.findByAccountId(id);
	}

	public Beneficiary addBeneficiary(Beneficiary beneficiary,String username) {
		User user=userRepository.findByUsername(username)
				.orElseThrow(()->new RuntimeException("User not found"));
		Account account=accountRepository.findByAccountHolderId(user.getId())
				.orElseThrow(()->new RuntimeException("User not found"));
		
		
		beneficiary.setAccount(account);
		beneficiary.setVerified(false);
		
		return beneficiaryRepository.save(beneficiary);
	}

}
