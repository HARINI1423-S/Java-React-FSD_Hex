package com.Hex.MaverickBank.model;

import java.time.LocalDate;

import com.Hex.MaverickBank.enums.LoanEscalationStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="loan_escalation")
public class LoanEscalation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @OneToOne
    @JoinColumn(name = "loan_id")
    private Loan loan;

    private String reason;

    @ManyToOne
    @JoinColumn(name = "escalated_by")
    private Employee escalatedBy;

    @ManyToOne
    @JoinColumn(name = "reviewed_by")
    private Employee reviewedBy;

    @Enumerated(EnumType.STRING)
    private LoanEscalationStatus status;

    private String actionTaken;
    private LocalDate reviewedDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Loan getLoan() {
		return loan;
	}
	public void setLoan(Loan loan) {
		this.loan = loan;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public Employee getEscalatedBy() {
		return escalatedBy;
	}
	public void setEscalatedBy(Employee escalatedBy) {
		this.escalatedBy = escalatedBy;
	}
	public Employee getReviewedBy() {
		return reviewedBy;
	}
	public void setReviewedBy(Employee reviewedBy) {
		this.reviewedBy = reviewedBy;
	}
	public LoanEscalationStatus getStatus() {
		return status;
	}
	public void setStatus(LoanEscalationStatus status) {
		this.status = status;
	}
	public String getActionTaken() {
		return actionTaken;
	}
	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}
	public LocalDate getReviewedDate() {
		return reviewedDate;
	}
	public void setReviewedDate(LocalDate reviewedDate) {
		this.reviewedDate = reviewedDate;
	}

    
}
