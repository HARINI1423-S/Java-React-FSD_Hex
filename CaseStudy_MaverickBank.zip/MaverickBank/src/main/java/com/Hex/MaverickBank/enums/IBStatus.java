package com.Hex.MaverickBank.enums;

public enum IBStatus {
	ENABLED,
    DISABLED,
    LOCKED
}
