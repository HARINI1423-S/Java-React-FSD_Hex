package com.Hex.MaverickBank.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.enums.AccountType;
import com.Hex.MaverickBank.model.AccountCreateRequest;
import com.Hex.MaverickBank.model.AccountHolder;
import com.Hex.MaverickBank.model.Branch;
import com.Hex.MaverickBank.model.User;
import com.Hex.MaverickBank.repository.AccountCreateRequestRepository;
import com.Hex.MaverickBank.repository.AccountHolderRepository;
import com.Hex.MaverickBank.repository.BranchRepository;
import com.Hex.MaverickBank.repository.UserRepository;

@Service
public class AccountCreateRequestService {
	private AccountCreateRequestRepository repository;
	private UserRepository userRepository;
	private AccountHolderRepository accountHolderRepository;
	private BranchRepository branchRepository;
	
	

	public AccountCreateRequestService(AccountCreateRequestRepository repository, UserRepository userRepository,
			AccountHolderRepository accountHolderRepository, BranchRepository branchRepository) {
		super();
		this.repository = repository;
		this.userRepository = userRepository;
		this.accountHolderRepository = accountHolderRepository;
		this.branchRepository = branchRepository;
	}

	public List<AccountCreateRequest> getAll() {
	        return repository.findAll();
	    }

	public ResponseEntity<?> create(AccountType accountType, Integer branchId, String username) {
		 User user = userRepository.findByUsername(username)
                 .orElseThrow(() -> new UsernameNotFoundException("User not found"));

    AccountHolder holder = accountHolderRepository.findByUsername(username)
                 .orElseThrow(() -> new RuntimeException("You must be an account holder to request an accountd"));

    Branch branch = branchRepository.findById(branchId)
            .orElseThrow(() -> new RuntimeException("Branch not found"));

    AccountCreateRequest request = new AccountCreateRequest();
    request.setAccountHolder(holder);
    request.setAccountType(accountType);
    request.setBranch(branch);
    request.setIfscCode(branch.getIfsc());

    repository.save(request);

    return ResponseEntity.status(HttpStatus.OK).body("Account creation request submitted successfully");
}
	
}
