package com.Hex.MaverickBank.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Hex.MaverickBank.exception.IdNotFoundException;
import com.Hex.MaverickBank.model.Account;
import com.Hex.MaverickBank.model.Beneficiary;
import com.Hex.MaverickBank.repository.AccountRepository;
import com.Hex.MaverickBank.service.BeneficiaryService;

@RestController
@RequestMapping("/api/beneficiary")
public class BeneficiaryController {

	@Autowired
	private BeneficiaryService beneficiaryService;
	@Autowired
	private AccountRepository accountRepository;
	
	
	@PostMapping("/add")
	public Beneficiary addBeneficiary(@RequestBody Beneficiary beneficiary,Principal principal) {
		String username=principal.getName();
		return beneficiaryService.addBeneficiary(beneficiary,username);
	}
	
	
	@GetMapping("/get")
	public List<Beneficiary> getBeneficiary(Principal principal) throws IdNotFoundException{
		String username=principal.getName();
		
		Account account=accountRepository.findByAccountHolderUserUsername(username)
				.orElseThrow(()->new IdNotFoundException("AccountHolder Not found"));
		
		return beneficiaryService.getBeneficiary(account.getId());
	}
}
