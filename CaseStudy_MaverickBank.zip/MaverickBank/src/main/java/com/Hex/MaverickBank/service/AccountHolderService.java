package com.Hex.MaverickBank.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.enums.Role;
import com.Hex.MaverickBank.model.AccountHolder;
import com.Hex.MaverickBank.model.User;
import com.Hex.MaverickBank.repository.AccountHolderRepository;
import com.Hex.MaverickBank.repository.UserRepository;

import jakarta.transaction.Transactional;
@Service
public class AccountHolderService {
	
	private AccountHolderRepository accountHolderRepository;
	private UserRepository userRepository;

	

	public AccountHolderService(AccountHolderRepository accountHolderRepository, UserRepository userRepository) {
		super();
		this.accountHolderRepository = accountHolderRepository;
		this.userRepository = userRepository;
	}

	@Transactional
	public ResponseEntity<?> createAccountHolder(AccountHolder accountHolder,String username) {
		
		Optional<User> userOpt = userRepository.findByUsername(username);
        
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("message", "Please sign up before creating an account holder."));
        }

        User user = userOpt.get();
        
        if (accountHolderRepository.findById(user.getId()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("error", "Conflict", "message", "AccountHolder profile already exists for this user."));
        }


        if (user.getRole() == null || !user.getRole().name().equalsIgnoreCase("account_holder")) {
            user.setRole(Role.account_holder);
            userRepository.save(user); // update role
        }
        
        // Link AccountHolder to User
        accountHolder.setUser(user);
        accountHolder.setOpenedDate(LocalDate.now());

        accountHolderRepository.save(accountHolder);

        return ResponseEntity.ok("AccountHolder profile created successfully.");
	}

	public List<AccountHolder> getAllAccountHolders() {
		return accountHolderRepository.findAll();
	}

	public ResponseEntity<?> getMyAccountHolderProfile(String username) {
		User user=userRepository.getUserName(username);
		if(user==null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
		}
		
		Optional<AccountHolder> accountHolder=accountHolderRepository.findById(user.getId());
		if(accountHolder.isPresent()) {
			return ResponseEntity.status(HttpStatus.OK).body(accountHolder.get());
		}
		else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("AccountHolder profile not found.");
		}
		
	}

}
