package com.Hex.MaverickBank.service;


import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.dto.ClosureRequestDTO;
import com.Hex.MaverickBank.model.Account;
import com.Hex.MaverickBank.model.AccountClosureRequest;
import com.Hex.MaverickBank.repository.AccountClosureRequestRepository;
import com.Hex.MaverickBank.repository.AccountRepository;

@Service
public class AccountClosureRequestService {
	
	private final AccountClosureRequestRepository repository;
	private AccountRepository accountRepository;
	

   

    public AccountClosureRequestService(AccountClosureRequestRepository repository,
			AccountRepository accountRepository) {
		super();
		this.repository = repository;
		this.accountRepository = accountRepository;
	}

	public ResponseEntity<?> create(ClosureRequestDTO closureRequestDTO) {
		Account account = accountRepository.findById(closureRequestDTO.getAccountId())
                .orElseThrow(() -> new RuntimeException("Account not found"));

        AccountClosureRequest request = new AccountClosureRequest();
        request.setAccount(account);
        request.setReason(closureRequestDTO.getReason());

        repository.save(request);
        return ResponseEntity.status(HttpStatus.CREATED).body("Account closure request submitted.");
    }

    public List<AccountClosureRequest> getAll() {
        return repository.findAll();
    }

	


}
