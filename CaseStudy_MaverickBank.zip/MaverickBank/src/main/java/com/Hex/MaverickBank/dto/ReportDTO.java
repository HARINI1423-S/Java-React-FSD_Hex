package com.Hex.MaverickBank.dto;

import java.math.BigDecimal;

public class ReportDTO {
	 private String name;
	    private long totalAccounts;
	    private long loansApproved;
	    private long loansRejected;
	    private double depositAmount;
	    private double withdrawAmount;
	    private double loanApprovedAmount;
		public ReportDTO(String name, long totalAccounts, long loansApproved, long loansRejected, double depositAmount,
				double withdrawAmount, double loanApprovedAmount) {
			super();
			this.name = name;
			this.totalAccounts = totalAccounts;
			this.loansApproved = loansApproved;
			this.loansRejected = loansRejected;
			this.depositAmount = depositAmount;
			this.withdrawAmount = withdrawAmount;
			this.loanApprovedAmount = loanApprovedAmount;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public long getTotalAccounts() {
			return totalAccounts;
		}
		public void setTotalAccounts(long totalAccounts) {
			this.totalAccounts = totalAccounts;
		}
		public long getLoansApproved() {
			return loansApproved;
		}
		public void setLoansApproved(long loansApproved) {
			this.loansApproved = loansApproved;
		}
		public long getLoansRejected() {
			return loansRejected;
		}
		public void setLoansRejected(long loansRejected) {
			this.loansRejected = loansRejected;
		}
		public double getDepositAmount() {
			return depositAmount;
		}
		public void setDepositAmount(double depositAmount) {
			this.depositAmount = depositAmount;
		}
		public double getWithdrawAmount() {
			return withdrawAmount;
		}
		public void setWithdrawAmount(double withdrawAmount) {
			this.withdrawAmount = withdrawAmount;
		}
		public double getLoanApprovedAmount() {
			return loanApprovedAmount;
		}
		public void setLoanApprovedAmount(double loanApprovedAmount) {
			this.loanApprovedAmount = loanApprovedAmount;
		}
	    
	    
	
}
