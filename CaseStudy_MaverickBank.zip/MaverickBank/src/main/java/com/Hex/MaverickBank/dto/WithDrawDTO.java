package com.Hex.MaverickBank.dto;

import java.math.BigDecimal;

public class WithDrawDTO {
	
	private BigDecimal amount;
  
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	

    

}
