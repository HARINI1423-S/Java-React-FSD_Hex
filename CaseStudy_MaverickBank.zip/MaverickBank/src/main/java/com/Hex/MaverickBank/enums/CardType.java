package com.Hex.MaverickBank.enums;

public enum CardType {
	DEBIT,CREDIT
}
