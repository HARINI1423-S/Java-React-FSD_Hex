package com.Hex.MaverickBank.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.Hex.MaverickBank.enums.Role;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="employee_performance")
public class EmployeePerformance {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Employee employee;

    @Enumerated(EnumType.STRING)
    private Role role;

    @ManyToOne
    @JoinColumn(name = "evaluated_by")
    private Employee evaluatedBy;
    
    private String remarks;
    private BigDecimal performanceRating;
    private LocalDate evaluationDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public Employee getEvaluatedBy() {
		return evaluatedBy;
	}
	public void setEvaluatedBy(Employee evaluatedBy) {
		this.evaluatedBy = evaluatedBy;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public BigDecimal getPerformanceRating() {
		return performanceRating;
	}
	public void setPerformanceRating(BigDecimal performanceRating) {
		this.performanceRating = performanceRating;
	}
	public LocalDate getEvaluationDate() {
		return evaluationDate;
	}
	public void setEvaluationDate(LocalDate evaluationDate) {
		this.evaluationDate = evaluationDate;
	}
    
    

}
