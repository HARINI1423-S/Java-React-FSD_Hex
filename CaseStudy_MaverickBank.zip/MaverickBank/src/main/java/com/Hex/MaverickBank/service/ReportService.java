package com.Hex.MaverickBank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.dto.ReportDTO;
import com.Hex.MaverickBank.enums.Designation;
import com.Hex.MaverickBank.model.Employee;
import com.Hex.MaverickBank.repository.EmployeeRepository;
import com.Hex.MaverickBank.repository.ReportRepository;

@Service
public class ReportService {
	/*
	@Autowired
	private ReportRepository reportRepository;
	@Autowired
	private EmployeeRepository employeeRepository;
	
	

	    public ReportDTO generatePerformanceReport(String empname) {
	    	 Employee emp = employeeRepository.findByUsername(empname)
		                .orElseThrow(() -> new RuntimeException("Employee not found"));

		        if (emp.getDesignation() != Designation.MANAGER) {
		            throw new AccessDeniedException("Only MANAGER can generate performance reports.");
		        }
	        return reportRepository.generatePerformanceReport(empname);
	    }

	    public ReportDTO generateRegulatoryReport(String empname) {
	        return reportRepository.generateRegulatoryReport(empname);
	    }
	
	
	*/

}
