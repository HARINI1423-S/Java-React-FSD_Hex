package com.Hex.MaverickBank.enums;

public enum GrievanceStatus {
	OPEN,
    IN_PROGRESS,
    RESOLVED,
    CLOSED
}
