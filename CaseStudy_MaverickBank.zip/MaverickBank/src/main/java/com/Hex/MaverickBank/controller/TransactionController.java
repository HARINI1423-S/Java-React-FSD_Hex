package com.Hex.MaverickBank.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Hex.MaverickBank.dto.DepositDTO;
import com.Hex.MaverickBank.dto.TransactionFilterDTO;
import com.Hex.MaverickBank.dto.TransactionResponseDTO;
import com.Hex.MaverickBank.dto.TransferRequest;
import com.Hex.MaverickBank.dto.WithDrawDTO;
import com.Hex.MaverickBank.exception.IdNotFoundException;
import com.Hex.MaverickBank.exception.InSufficientBalanceException;
import com.Hex.MaverickBank.model.Account;
import com.Hex.MaverickBank.model.Transaction;
import com.Hex.MaverickBank.repository.AccountRepository;
import com.Hex.MaverickBank.service.TransactionService;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {
	
	@Autowired
	private TransactionService transactionService;
	@Autowired
	private AccountRepository accountRepository;
	
	
	@PostMapping("/deposit")
	public Transaction deposit(Principal principal,@RequestBody DepositDTO request) throws IdNotFoundException {
		String ahName=principal.getName();
		return transactionService.deposit(ahName,request.getAmount());
	}
	
	@PostMapping("/withdraw")
	public Transaction withdraw(Principal principal,@RequestBody WithDrawDTO request) throws IdNotFoundException, InSufficientBalanceException {
		String ahName=principal.getName();
		return transactionService.withdraw(ahName,request.getAmount());
	}
	
	@PostMapping("/transfer")
	public Transaction transfer(@RequestBody TransferRequest request, Principal principal)
	        throws IdNotFoundException, InSufficientBalanceException {
	    String username = principal.getName();
	    return transactionService.transfer(username, request.getToAccountId(), request.getAmount());
	}


	
	
	@GetMapping("/last10")
	public List<TransactionResponseDTO> getLast10(Principal principal) throws IdNotFoundException{
		String username=principal.getName();
		Account account=accountRepository.findByAccountHolderUserUsername(username)
				.orElseThrow(()-> new IdNotFoundException("Account not found for the username"));
		return transactionService.getLast10Transactions(account.getId());
	}
	
	@GetMapping("/between")
	public List<TransactionResponseDTO> getTransactionsBetweenDates(@RequestBody TransactionFilterDTO request) {
	    return transactionService.getTransactionsBetweenDates(
	            request.getAccountId(),
	            request.getFrom(),
	            request.getTo());
	}

	
	

}
