package com.Hex.MaverickBank.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Hex.MaverickBank.dto.ReportDTO;
import com.Hex.MaverickBank.model.Report;

@Repository
public interface ReportRepository extends JpaRepository<Report, Integer> {
/*
	 @Query("SELECT new com.Hex.MaverickBank.dto.ReportDTO( " +
	           "e.name, " +
	           "(SELECT COUNT(a) FROM Account a WHERE a.assignedEmployee.user.username = :empname), " +
	           "(SELECT COUNT(l) FROM Loan l WHERE l.approvedBy.user.username = :empname), " +
	           "(SELECT COUNT(l) FROM Loan l WHERE l.rejectedBy.user.username = :empname), " +
	           "COALESCE((SELECT SUM(t.amount) FROM Transaction t WHERE t.account.assignedEmployee.user.username = :empname AND t.type = com.Hex.MaverickBank.enums.TxnType.DEPOSIT), 0), " +
	           "COALESCE((SELECT SUM(t.amount) FROM Transaction t WHERE t.account.assignedEmployee.user.username = :empname AND t.type = com.Hex.MaverickBank.enums.TxnType.WITHDRAW), 0), " +
	           "COALESCE((SELECT SUM(l.amount) FROM Loan l WHERE l.approvedBy.user.username = :empname AND l.status = com.Hex.MaverickBank.enums.LoanStatus.APPROVED), 0)) " +
	           "FROM Employee e WHERE e.user.username = :empname")
	    ReportDTO generatePerformanceReport(@Param("empname") String empname);

	    // Overall regulatory report system-wide (no employee filtering)
	    @Query("SELECT new com.Hex.MaverickBank.dto.ReportDTO( " +
	           ":empname, 0, 0, 0, " +  // placeholders for employee name and zero counts
	           "COALESCE((SELECT SUM(t.amount) FROM Transaction t WHERE t.type = com.Hex.MaverickBank.enums.TxnType.DEPOSIT), 0), " +
	           "COALESCE((SELECT SUM(t.amount) FROM Transaction t WHERE t.type = com.Hex.MaverickBank.enums.TxnType.WITHDRAW), 0), " +
	           "COALESCE((SELECT SUM(l.amount) FROM Loan l WHERE l.status = com.Hex.MaverickBank.enums.LoanStatus.APPROVED), 0))")
	    ReportDTO generateRegulatoryReport(@Param("empname") String empname);
*/
}
