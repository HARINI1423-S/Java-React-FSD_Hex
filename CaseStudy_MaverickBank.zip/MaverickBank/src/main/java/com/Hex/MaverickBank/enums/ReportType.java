package com.Hex.MaverickBank.enums;

public enum ReportType {
	AUDIT,
    FINANCIAL,
    PERFORMANCE,
    REGULATORY
}
