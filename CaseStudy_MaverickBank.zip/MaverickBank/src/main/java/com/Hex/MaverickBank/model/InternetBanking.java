package com.Hex.MaverickBank.model;

import java.time.LocalDateTime;

import com.Hex.MaverickBank.enums.IBStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="internet_banking")
public class InternetBanking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int ibId;

    @OneToOne
    @JoinColumn(name = "ah_id")
    private AccountHolder accountHolder;

    private LocalDateTime registeredDate;
    private LocalDateTime lastLogin;

    @Enumerated(EnumType.STRING)
    private IBStatus status;

    private String securityQuestion;
    private String securityAnswer;
	public int getIbId() {
		return ibId;
	}
	public void setIbId(int ibId) {
		this.ibId = ibId;
	}
	public AccountHolder getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(AccountHolder accountHolder) {
		this.accountHolder = accountHolder;
	}
	public LocalDateTime getRegisteredDate() {
		return registeredDate;
	}
	public void setRegisteredDate(LocalDateTime registeredDate) {
		this.registeredDate = registeredDate;
	}
	public LocalDateTime getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(LocalDateTime lastLogin) {
		this.lastLogin = lastLogin;
	}
	public IBStatus getStatus() {
		return status;
	}
	public void setStatus(IBStatus status) {
		this.status = status;
	}
	public String getSecurityQuestion() {
		return securityQuestion;
	}
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	public String getSecurityAnswer() {
		return securityAnswer;
	}
	public void setSecurityAnswer(String securityAnswer) {
		this.securityAnswer = securityAnswer;
	}

    
}
