package com.Hex.MaverickBank.model;

import java.time.LocalDateTime;

import com.Hex.MaverickBank.enums.GrievanceStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="grievance")
public class Grievance {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne
	@JoinColumn(name = "acc_id")
	private Account account;

	private LocalDateTime raisedDate;
	private String issue;

	@Enumerated(EnumType.STRING)
	private GrievanceStatus status;

	@ManyToOne
    @JoinColumn(name = "resolved_by")
  private Employee resolvedBy;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public LocalDateTime getRaisedDate() {
		return raisedDate;
	}

	public void setRaisedDate(LocalDateTime raisedDate) {
		this.raisedDate = raisedDate;
	}

	public String getIssue() {
		return issue;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

	public GrievanceStatus getStatus() {
		return status;
	}

	public void setStatus(GrievanceStatus status) {
		this.status = status;
	}

	public Employee getResolvedBy() {
		return resolvedBy;
	}

	public void setResolvedBy(Employee resolvedBy) {
		this.resolvedBy = resolvedBy;
	}

	
}
