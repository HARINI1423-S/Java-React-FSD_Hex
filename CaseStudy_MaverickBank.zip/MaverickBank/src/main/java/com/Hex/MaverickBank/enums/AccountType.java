package com.Hex.MaverickBank.enums;

public enum AccountType {
	 SAVINGS, CURRENT 

}
