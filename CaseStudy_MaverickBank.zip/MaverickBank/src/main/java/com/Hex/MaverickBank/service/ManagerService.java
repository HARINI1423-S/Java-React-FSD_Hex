package com.Hex.MaverickBank.service;



import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.dto.EmployeeCreateRequest;
import com.Hex.MaverickBank.enums.Designation;
import com.Hex.MaverickBank.enums.Role;
import com.Hex.MaverickBank.model.Employee;
import com.Hex.MaverickBank.model.User;
import com.Hex.MaverickBank.repository.EmployeeRepository;
import com.Hex.MaverickBank.repository.UserRepository;


@Service
public class ManagerService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private EmployeeRepository employeeRepository;
	
     Logger logger = LoggerFactory.getLogger(ManagerService.class);
    
     public ResponseEntity<String> createEmployee(EmployeeCreateRequest request, String managerUsername) {
    	 Employee manager = employeeRepository.findByUsername(managerUsername)
                 .orElseThrow(() -> new RuntimeException("Manager not found"));

         if (manager.getDesignation() != Designation.MANAGER &&
                 manager.getDesignation() != Designation.SENIOR_MANAGER) {
             throw new AccessDeniedException("Only MANAGER or SENIOR_MANAGER can create employees.");
         }

         if (request.getDesignation() == Designation.MANAGER ||
                 request.getDesignation() == Designation.SENIOR_MANAGER ||
                 request.getDesignation() == Designation.REGIONAL_HEAD) {
             throw new RuntimeException("Manager/Senior Manager/Regional Head roles are restricted.");
         }

         User user = userRepository.findById(request.getUserId())
                 .orElseThrow(() -> new RuntimeException("User not found with ID: " + request.getUserId()));

         if (user.getRole() != Role.executive) {
             throw new RuntimeException("The user is not assigned the executive role.");
         }

         Employee employee = new Employee();
         employee.setUser(user);
         employee.setName(request.getName());
         employee.setContact(request.getContact());
         employee.setDesignation(request.getDesignation());
         employee.setCreatedByManager(manager);
         employee.setBranch(manager.getBranch());

         String code = generateEmployeeCode(request.getDesignation());
         employee.setEmployeeCode(code);

         employeeRepository.save(employee);

         return ResponseEntity.ok("Employee created successfully with designation: " + request.getDesignation());
     }

     public List<Employee> getAllEmployees(String managerUsername) {
         Employee manager = employeeRepository.findByUsername(managerUsername)
                 .orElseThrow(() -> new RuntimeException("Manager not found"));

         if (manager.getDesignation() != Designation.MANAGER && manager.getDesignation() != Designation.SENIOR_MANAGER) {
             throw new AccessDeniedException("Access denied to list employees");
         }

         return employeeRepository.findByManager(manager);
     }

     public Employee getProfile(String managerUsername) {
         return employeeRepository.findByUsername(managerUsername)
                 .orElseThrow(() -> new RuntimeException("Manager profile not found"));
     }
    	}
     
     	


		    
		    public List<Employee> getAllEmployees(String managerUsername) {
		        Employee manager = employeeRepository.findByUsername(managerUsername)
		                .orElseThrow(() -> new RuntimeException("Manager not found"));

		        if (manager.getDesignation() != Designation.MANAGER && manager.getDesignation() != Designation.SENIOR_MANAGER) {
		            throw new AccessDeniedException("Access denied to list employees");
		        }

		        return employeeRepository.findByManager(manager);
		    }

		   
		    public Employee getProfile(String managerUsername) {
		        return employeeRepository.findByUsername(managerUsername)
		                .orElseThrow(() -> new RuntimeException("Manager profile not found"));
		    }
		    
		    
		    public String generateManagerCode(String branchCode) {
		        long count = employeeRepository.countByDesignation(Designation.MANAGER) + 1;
		        return branchCode + String.format("-MGR%03d", count);
		    }

	 
}
