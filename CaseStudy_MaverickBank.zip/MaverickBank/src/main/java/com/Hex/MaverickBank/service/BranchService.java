package com.Hex.MaverickBank.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Hex.MaverickBank.exception.IdNotFoundException;
import com.Hex.MaverickBank.model.Branch;
import com.Hex.MaverickBank.repository.BranchRepository;

@Service
public class BranchService {
	
	private BranchRepository branchRepository;
	

	public BranchService(BranchRepository branchRepository) {
		super();
		this.branchRepository = branchRepository;
	}


	public Branch createBranch(Branch branch) {
		// TODO Auto-generated method stub
		return branchRepository.save(branch);
	}


	public Branch getBranchById(int id) throws IdNotFoundException {
		// TODO Auto-generated method stub
		return branchRepository.findById(id)
				.orElseThrow(()-> new IdNotFoundException("Branch not Found"));
	}


	public List<Branch> getAllBranches() {
		// TODO Auto-generated method stub
		return branchRepository.findAll();
	}

}
