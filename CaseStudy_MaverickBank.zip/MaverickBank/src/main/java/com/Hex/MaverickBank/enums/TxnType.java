package com.Hex.MaverickBank.enums;

public enum TxnType {
	DEPOSIT, WITHDRAW, TRANSFER
}
