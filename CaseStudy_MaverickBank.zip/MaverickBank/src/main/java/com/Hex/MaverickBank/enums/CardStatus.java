package com.Hex.MaverickBank.enums;

public enum CardStatus {
	ACTIVE,BLOCKED,EXPIRED
}
