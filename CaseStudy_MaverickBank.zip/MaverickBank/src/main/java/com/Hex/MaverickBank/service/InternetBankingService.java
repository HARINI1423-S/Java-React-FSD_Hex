package com.Hex.MaverickBank.service;

import org.springframework.stereotype.Service;

@Service
public class InternetBankingService {

}
