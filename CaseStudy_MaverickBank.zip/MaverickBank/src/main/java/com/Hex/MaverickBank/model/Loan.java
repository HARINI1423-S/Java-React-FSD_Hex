package com.Hex.MaverickBank.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.Hex.MaverickBank.enums.LoanStatus;
import com.Hex.MaverickBank.enums.LoanType;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="loan")
public class Loan {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    @JoinColumn(name = "acc_id")
    private Account account;
    
    @Enumerated(EnumType.STRING)
    private LoanType loanType;

    private BigDecimal amount;
    private BigDecimal interestRate;
    private int durationInMonths;
    
    @Enumerated(EnumType.STRING)
    private LoanStatus status;

    private LocalDate appliedDate;


    @ManyToOne
    @JoinColumn(name = "approved_by")
    private Employee approvedBy;
    
    private LocalDate approvedDate;
    private LocalDate rejectedDate;

    @ManyToOne
    @JoinColumn(name = "rejected_by")
    private Employee rejectedBy;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public LoanType getLoanType() {
		return loanType;
	}

	public void setLoanType(LoanType loanType) {
		this.loanType = loanType;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(BigDecimal interestRate) {
		this.interestRate = interestRate;
	}

	public int getDurationInMonths() {
		return durationInMonths;
	}

	public void setDurationInMonths(int durationInMonths) {
		this.durationInMonths = durationInMonths;
	}

	public LoanStatus getStatus() {
		return status;
	}

	public void setStatus(LoanStatus status) {
		this.status = status;
	}

	public LocalDate getAppliedDate() {
		return appliedDate;
	}

	public void setAppliedDate(LocalDate appliedDate) {
		this.appliedDate = appliedDate;
	}

	public Employee getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(Employee approvedBy) {
		this.approvedBy = approvedBy;
	}

	public LocalDate getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(LocalDate approvedDate) {
		this.approvedDate = approvedDate;
	}

	public LocalDate getRejectedDate() {
		return rejectedDate;
	}

	public void setRejectedDate(LocalDate rejectedDate) {
		this.rejectedDate = rejectedDate;
	}

	public Employee getRejectedBy() {
		return rejectedBy;
	}

	public void setRejectedBy(Employee rejectedBy) {
		this.rejectedBy = rejectedBy;
	}

	

}
