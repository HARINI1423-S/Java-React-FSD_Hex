package com.hex.CodingChallenge.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hex.hms.Model.Doctor;
import com.hex.hms.Service.DoctorService;

@RestController
@RequestMapping("/api/doctor")
public class DoctorController {

	@Autowired
	private DoctorService doctorService;
//add doctor	
	@PostMapping("/add")
	public ResponseEntity<?> add(@RequestBody Doctor doctor){
		return ResponseEntity.status(HttpStatus.OK).body(doctorService.add(doctor));
	}
}
