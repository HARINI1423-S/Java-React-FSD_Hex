package com.hex.CodingChallenge.Controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hex.hms.Model.User;
import com.hex.hms.Service.UserService;
import com.hex.hms.Util.JwtUtil;

@RestController
@RequestMapping("api/user")
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private JwtUtil jwtUtil;
	// user add
	@PostMapping("/signup")
	public User addUser(@RequestBody User user) {
		return userService.addUser(user);
	}
	
	@GetMapping("/token")
	public ResponseEntity<?> getToken(Principal principal) {
		return ResponseEntity.status(HttpStatus.OK).body(userService.getToken(principal));
	}
	
	//get user details
	@GetMapping("/details")
	public ResponseEntity<?> getLoggedInUserDetails(Principal principal){
		String username=principal.getName();
		return ResponseEntity.status(HttpStatus.OK).body(userService.getUserInfo(username));
	}
}
