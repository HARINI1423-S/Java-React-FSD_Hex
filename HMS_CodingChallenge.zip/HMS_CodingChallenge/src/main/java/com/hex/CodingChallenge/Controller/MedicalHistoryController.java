package com.hex.CodingChallenge.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hex.hms.Dto.MedicalRecordDTO;
import com.hex.hms.Service.MedicalHistoryService;

@RestController
@RequestMapping("/api/history")
public class MedicalHistoryController {

	@Autowired
	private MedicalHistoryService medicalHistoryService;
	
	//Add patient medical and user details 
	@PostMapping("/add")
	public ResponseEntity<?> add(@RequestBody MedicalRecordDTO patDto){
		return ResponseEntity.status(HttpStatus.CREATED).body(medicalHistoryService.add(patDto));
	}

	//GET record by id
	@GetMapping("/get")
	public ResponseEntity<?> get(@RequestParam int record_id){
		return ResponseEntity.status(HttpStatus.OK).body(medicalHistoryService.getById(record_id));
	}
}
