package com.hex.hms.Enum;

public enum Speciality {

	PHYSICIAN,
	ORTHO,
	GYNAC
}
