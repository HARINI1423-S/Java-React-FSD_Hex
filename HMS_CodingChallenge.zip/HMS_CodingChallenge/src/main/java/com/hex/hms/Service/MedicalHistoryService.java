package com.hex.hms.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hex.hms.Dto.MedicalRecordDTO;
import com.hex.hms.Dto.RecordDto;
import com.hex.hms.Exception.ResourceNotFoundException;
import com.hex.hms.Model.MedicalHistory;
import com.hex.hms.Model.Patient;
import com.hex.hms.Repository.MedicalHistoryRepository;
@Service
public class MedicalHistoryService {

	private MedicalHistoryRepository medicalHistoryRepository;
	private PatientService patientService;
	
	@Autowired
	private RecordDto recordDto;

	public MedicalHistoryService(MedicalHistoryRepository medicalHistoryRepository, PatientService patientService) {
		super();
		this.medicalHistoryRepository = medicalHistoryRepository;
		this.patientService = patientService;
	}



	public MedicalHistory add(MedicalRecordDTO dto) {
		Patient patient= patientService.add(dto.getPatient());
		dto.getMedicalHistory().setPatient(patient);
		return medicalHistoryRepository.save(dto.getMedicalHistory());
	}



	public RecordDto getById(int record_id) {
		MedicalHistory medicalHistory= medicalHistoryRepository.findById(record_id)
				.orElseThrow(()->new ResourceNotFoundException("Record not found"));
		return recordDto.convertToDto(medicalHistory);
	}

}
