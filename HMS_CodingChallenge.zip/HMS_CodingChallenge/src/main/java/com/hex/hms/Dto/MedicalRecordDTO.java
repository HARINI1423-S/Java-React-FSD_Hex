package com.hex.hms.Dto;

import org.springframework.stereotype.Component;

import com.hex.hms.Model.MedicalHistory;
import com.hex.hms.Model.Patient;

@Component
public class MedicalRecordDTO {

	private Patient patient;
	private MedicalHistory medicalHistory;

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public MedicalHistory getMedicalHistory() {
		return medicalHistory;
	}

	public void setMedicalHistory(MedicalHistory medicalHistory) {
		this.medicalHistory = medicalHistory;
	}
	
	
}
