package com.hex.hms.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hex.hms.Model.Doctor;
import com.hex.hms.Model.User;
import com.hex.hms.Repository.DoctorRepository;

@Service
public class DoctorService {

	private DoctorRepository doctorRepository;

	@Autowired
	private UserService userService;
	
	public DoctorService(DoctorRepository doctorRepository) {
		super();
		this.doctorRepository = doctorRepository;
	}

	public Doctor add(Doctor doctor) {
		User user=doctor.getUser();
		user.setRole("DOCTOR");
		user=userService.addUser(user);
		doctor.setUser(user);
		return doctorRepository.save(doctor);
	}
	
	
}
