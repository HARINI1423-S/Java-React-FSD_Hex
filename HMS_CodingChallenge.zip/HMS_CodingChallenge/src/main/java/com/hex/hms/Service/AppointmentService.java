package com.hex.hms.Service;

import java.time.LocalDate;

import org.springframework.stereotype.Service;

import com.hex.hms.Exception.ResourceNotFoundException;
import com.hex.hms.Model.Appointment;
import com.hex.hms.Model.Doctor;
import com.hex.hms.Model.Patient;
import com.hex.hms.Repository.AppointmentRepository;
import com.hex.hms.Repository.DoctorRepository;
import com.hex.hms.Repository.PatientRepository;

@Service
public class AppointmentService {

	private AppointmentRepository appointmentRepository;
	private PatientRepository patientRepository;
	private DoctorRepository doctorRepository;
	
	
	public AppointmentService(AppointmentRepository appointmentRepository, PatientRepository patientRepository,
			DoctorRepository doctorRepository) {
		super();
		this.appointmentRepository = appointmentRepository;
		this.patientRepository = patientRepository;
		this.doctorRepository = doctorRepository;
	}


	public Appointment add(int patient_id, int doctor_id) {
		Patient patient=patientRepository.findById(patient_id)
				.orElseThrow(()->new ResourceNotFoundException("Patient id not found"));
		Doctor doctor=doctorRepository.findById(doctor_id)
				.orElseThrow(()->new ResourceNotFoundException("Doctor id not found"));
		Appointment appointment=new Appointment();
		appointment.setDate(LocalDate.now());
		appointment.setDoctor(doctor);
		appointment.setPatient(patient);
		return appointmentRepository.save(appointment);
	}

}
