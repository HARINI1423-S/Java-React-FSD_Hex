package com.hex.hms.Service;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hex.hms.Model.User;
import com.hex.hms.Repository.UserRepository;
import com.hex.hms.Util.JwtUtil;



@Service
public class UserService {

	private UserRepository userRepository;
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private JwtUtil jwtUtil;

	public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
		super();
		this.userRepository = userRepository;
		this.passwordEncoder = passwordEncoder;
	}



	public User addUser(User user) {
		String plaintext=user.getPassword();
		String ciphertext=passwordEncoder.encode(plaintext);
		
		user.setPassword(ciphertext);
		return userRepository.save(user);
	}



	public Object getToken(Principal principal) {
		
		try {
			String token =jwtUtil.createToken(principal.getName()); 
			return ResponseEntity.status(HttpStatus.OK).body(token);
			}
			catch(Exception e){
				return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
			}
	}


	public Object getUserInfo(String username) {
		User user=userRepository.getByUsername(username);
		switch(user.getRole()) {
		
		}
		
		return null;
	}

}
