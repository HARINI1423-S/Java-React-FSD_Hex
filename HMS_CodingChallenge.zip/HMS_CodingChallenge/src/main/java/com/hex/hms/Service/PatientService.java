package com.hex.hms.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hex.hms.Exception.ResourceNotFoundException;
import com.hex.hms.Model.Doctor;
import com.hex.hms.Model.Patient;
import com.hex.hms.Model.User;
import com.hex.hms.Repository.DoctorRepository;
import com.hex.hms.Repository.PatientRepository;

@Service
public class PatientService {

	private PatientRepository patientRepository;
	private DoctorRepository doctorRepository;

	@Autowired
	private UserService userService;
	
	


	public PatientService(PatientRepository patientRepository, DoctorRepository doctorRepository,
			UserService userService) {
		super();
		this.patientRepository = patientRepository;
		this.doctorRepository = doctorRepository;
		this.userService = userService;
	}


	public Patient add(Patient patient) {
		User user=patient.getUser();
		user.setRole("PATIENT");
		userService.addUser(user);
		patient.setUser(user);
		return patientRepository.save(patient);
	}


	public List<Patient> getByDoctor(String username) {
		Doctor doctor=doctorRepository.getByUsername(username)
				.orElseThrow(()->new ResourceNotFoundException("Doctor not found"));
		
		return patientRepository.getByDoctor(doctor.getId());
	}
}
