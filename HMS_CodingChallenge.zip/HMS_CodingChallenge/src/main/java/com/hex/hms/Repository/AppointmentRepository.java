package com.hex.hms.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hex.hms.Model.Appointment;
@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer>{

}
