package com.hex.CodingChallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HMS_CodingChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
