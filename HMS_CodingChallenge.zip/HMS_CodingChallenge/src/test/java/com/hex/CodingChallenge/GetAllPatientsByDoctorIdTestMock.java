package com.hex.CodingChallenge;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.hex.hms.Enum.Speciality;
import com.hex.hms.Exception.ResourceNotFoundException;
import com.hex.hms.Model.Doctor;
import com.hex.hms.Model.Patient;
import com.hex.hms.Model.User;
import com.hex.hms.Repository.DoctorRepository;
import com.hex.hms.Repository.PatientRepository;
import com.hex.hms.Service.PatientService;

@SpringBootTest
public class GetAllPatientsByDoctorIdTestMock {

	@InjectMocks
	private PatientService patientService;
	@Mock
	private PatientRepository patientRepository;
	@Mock
	private DoctorRepository doctorRepository;

	User user = new User();
	Patient patient = new Patient();
	Doctor doctor = new Doctor();

	@BeforeEach
	public void setup() {
		patient.setId(1);
		patient.setName("Harini");
		patient.setAge(21);

		user.setId(2);
		user.setUsername("dev@gmail.com");
		user.setPassword("dev@123");

		patient.setUser(user);

		doctor.setId(1);
		doctor.setName("Harshini");
		doctor.setSpeciality(Speciality.ORTHO);

		user.setId(1);
		user.setUsername("harshini@gmail.com");
		user.setPassword("harshini@123");

		doctor.setUser(user);
	}

	@Test
	public void getByDoctorTest() {
		when(doctorRepository.getByUsername("harshini@gmail.com")).thenReturn(Optional.of(doctor));
		
		List<Patient> list=List.of(patient);
		when(patientRepository.getByDoctor(doctor.getId())).thenReturn(list);
		
		assertEquals(list,patientService.getByDoctor("harshini@gmail.com"));

		ResourceNotFoundException e=assertThrows(ResourceNotFoundException.class,()->{
			patientService.getByDoctor("harshini@gmail.com");
		});
		
	}
}
